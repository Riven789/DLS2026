"""One-command CPU lab: data, three trained models, held-out scoring, inference, tests."""
import subprocess
import sys
from pathlib import Path


def call(*args):
    subprocess.run([sys.executable, *args], check=True)


if __name__ == '__main__':
    import os
    os.chdir(Path(__file__).resolve().parent)
    call('make_data.py')
    call('-m', 'unittest', 'discover', '-s', 'tests', '-v')
    call('xor_demo.py')
    for task in ('classification', 'regression', 'binary'):
        call('train.py', '--csv', f'data/{task}.csv', '--schema', f'data/{task}_schema.json', '--out', f'runs/{task}')
        call('evaluate.py', '--csv', f'data/{task}.csv', '--run', f'runs/{task}')
        call('predict.py', '--csv', 'data/unlabeled.csv', '--run', f'runs/{task}', '--out', f'runs/{task}/new_predictions.csv')
