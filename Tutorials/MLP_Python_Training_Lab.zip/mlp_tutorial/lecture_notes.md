# Multilayer perceptron neural networks

## 1. Multilayer perceptron neural networks

This tutorial assumes basic algebra, functions, and a little Python. Matrix multiplication and derivatives are introduced through concrete shapes and numerical examples. An MLP learns a mapping from a fixed-length input vector to a prediction. Its adjustable parameters are weights and biases. Hidden layers alternate affine transformations with nonlinear activation functions.

The accompanying laboratory implements the mathematics directly in NumPy. It contains a complete preprocessing pipeline, explicit backpropagation, two optimizers, validation-based checkpoint selection, a separate test harness, and prediction on unlabeled rows. No dataset download or GPU is required. The worked scientific-style datasets are synthetic teaching examples, not measured physical systems. Expect about 60–90 minutes for the lecture and a further 45–60 minutes for the lab. Slides 3–6 explain computation, 7–10 connect data to tasks, 11–15 explain learning, and 16–20 connect the mathematics to executable code.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html

## 2. Supervised learning: examples and labels

A row is one example. Features must be available at the moment a prediction will be made. The label is the desired answer obtained from measurement, annotation, simulation, or another trusted source. Training uses many input–label pairs to adjust a function fθ so that its predictions agree with the labels. θ collects all weights and biases.

The table illustrates a hypothetical materials experiment. The three rows are illustrative, not the dataset used to report performance later. Temperature, pressure, catalyst presence, and material identity are inputs. A phase category can serve as a classification label. Replacing that column with a measured continuous response produces a regression task. A numerical code such as phase 0 or phase 1 is still categorical if its meaning is a class identity.

Ask learners to distinguish a feature from a label: if the goal is to predict the measured response before running an experiment, a measurement taken only after the experiment cannot be an input. The CSV schema explicitly lists features and keeps the target out of that list.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html

## 3. One neuron: weights, bias, and activation

Compute the weighted sum term by term: 0.50 times 1 is 0.50. Negative 0.25 times negative 2 is positive 0.50. Adding the bias 0.10 gives 1.10. ReLU returns the positive input unchanged. The neuron has three trainable parameters: two weights and one bias. The two input values belong to this example and are not trainable model parameters.

Holding other quantities fixed, increasing a weight by Δw changes the preactivation z by x times Δw. The direction therefore depends on the sign of the input. Weight magnitude alone is not a reliable ranking of feature importance, especially when inputs use different scales or features are correlated.

The bias shifts where the activation begins to respond. Without a bias, a single linear decision boundary is constrained to pass through the origin. The output a is also called an activation. Distinguish this numerical activation value from the activation function, here ReLU. Later we reuse this same neuron for a hand-calculated gradient update.

References
Stanford CS231n, Neural Networks Part 1. https://cs231n.github.io/neural-networks-1/

## 4. Activation functions introduce nonlinearity

The plots show exact mathematical functions sampled at 41 input values. An affine layer computes xW+b. Composing two such layers without a nonlinear function gives x(W1W2)+(b1W2+b2), which is still affine. Nonlinearity is therefore necessary for an MLP to represent interactions that a single affine map cannot capture.

ReLU is max(0,z). It has derivative 1 for positive inputs and 0 for negative inputs. At exactly zero it has no unique ordinary derivative; this code chooses 0. A neuron that remains negative on every example can stop learning because its gradient is zero. Tanh is smooth and has derivative 1−tanh(z)². The sigmoid derivative is σ(z)(1−σ(z)). Both derivatives become small when the input magnitude is large.

Use ReLU in the main tabular examples and tanh for the small XOR demonstration. Keep the output layer linear when its loss accepts logits. Sigmoid and softmax can then be included in numerically stable loss calculations. Their appearance at prediction time does not imply that every hidden layer should use them.

References
Stanford CS231n, Neural Networks Part 1. https://cs231n.github.io/neural-networks-1/

## 5. Layers learn combinations of features

An MLP is fully connected between adjacent layers: each unit receives the outputs of all units in the preceding layer. Width is the number of units in a layer. Depth is the number of successive learned transformations; conventions about counting the input layer vary, so describe the architecture explicitly.

The drawing has 2 inputs, 3 hidden units, and 1 output. It has 2×3+3=9 parameters in the first layer and 3×1+1=4 in the second, for 13 total. Input nodes store data and have no separate trainable bias. The diagram illustrates connectivity; the laboratory XOR network uses 8 tanh hidden units for easier optimization.

An exact ReLU construction on binary inputs is h1=ReLU(x1+x2), h2=ReLU(x1+x2−1), and output=h1−2h2. It returns 0,1,1,0 on the four cases. This algebra demonstrates representational capacity, while xor_demo.py learns a probabilistic classifier from all four cases. That demonstration measures fitting of the truth table, not held-out generalization. More capacity does not guarantee that training finds a good solution or that new predictions are reliable.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html

## 6. The forward pass as matrix mathematics

This tutorial uses row-vector batches. For layer l, W has shape input-width by output-width, and b has shape 1 by output-width. Matrix multiplication takes A from B by input-width to B by output-width. Broadcasting adds the same bias row to every example. Some textbooks and libraries store transposed weights; equivalent formulas use Wx instead of xW. Always check the actual shapes.

The laboratory expands four raw input columns into eleven numerical features: two numerical columns each yield a scaled value and missingness flag, one Boolean column yields a value and missingness flag, and one categorical column yields five one-hot positions including missing and unknown. With hidden widths 32 and 16 and three output classes, the parameter count is 384+528+51=963.

The activation is elementwise in hidden layers. For the final layer, A may simply be Z, leaving task-specific output processing to the loss or prediction function. Parameters do not grow with batch size. Increasing B changes memory and computation for activations, but all rows still share the same model.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html

## 7. Raw input types become numerical features

The network accepts a numerical matrix, so preprocessing is part of the model. Numerical features use a median imputer and standardization. Compute the median, mean, and standard deviation on the training rows, store them, and reuse them on validation, test, and future rows. Constant numerical columns get a safe positive denominator. The harness rejects a feature that is entirely missing during fitting.

Boolean inputs accept true/false, yes/no, or 1/0 and reject ambiguous strings. Missing Booleans use the training majority value plus a missingness indicator. Missing categories and previously unseen categories have separate one-hot positions. An unknown bucket preserves the schema but does not mean that the model has learned how a new material behaves.

Counts may benefit from log1p before scaling, if scientifically appropriate. Ordinal categories can use an explicit order if distances have meaning. High-cardinality categorical features often benefit from learned embeddings. Text, images, and variable-length sequences need a representation stage rather than direct strings in a dense matrix. Those extensions are conceptual discussion, beyond the included fixed-width tabular harness. Review units, impossible values, and duplicate records before fitting.

References
Stanford CS231n, Neural Networks Part 2. https://cs231n.github.io/neural-networks-2/
scikit-learn, Common pitfalls and recommended practices. https://scikit-learn.org/stable/common_pitfalls.html

## 8. Labels, splits, and leakage

The default harness creates deterministic splits, stratifying by class for classification. Integer rounding makes the exact counts slightly different from 70/15/15. This is appropriate only when rows are independent and exchangeable. Related samples, repeated measurements of one subject, near duplicates, or future observations require a deliberate group-based or chronological split. Provide a CSV split column with values train, val, and test, and name it as split_column in the schema. The harness honors that assignment but does not infer groups for you.

The target encoder learns class names from training labels and rejects unknown labels during evaluation. Regression targets use training-only mean and standard deviation for optimization, then predictions are converted back to original units. Missing labels are rejected for supervised training; predict.py handles unlabeled rows. Inspect annotation quality and agreement before modeling. Class imbalance can make accuracy misleading, so report per-class recall and macro-F1 as well.

Leakage occurs when information unavailable at real prediction time enters training, preprocessing, or model selection. Saved row indices and a data hash preserve the test split. Repeatedly tuning after inspecting test scores converts the test set into another validation set.

References
scikit-learn, Common pitfalls and recommended practices. https://scikit-learn.org/stable/common_pitfalls.html

## 9. Regression predicts continuous values

A regression head usually produces one output per quantity. The simple scalar model here has no final sigmoid or softmax because the target can be any real number. If a physical quantity must be positive or bounded, choose a suitable transform or output parameterization and define the loss consistently. The generic example does not impose physical constraints.

The residuals in the table are 2, −3, and 1. Squaring and averaging gives 14/3. Taking the square root restores the original target units. Mean absolute error averages absolute residuals instead, giving 2. MSE corresponds to fitting a conditional mean under the usual expected squared-error objective; it can be strongly affected by outliers. Alternatives such as Huber loss may help when outliers are plausible.

The harness standardizes regression labels using training statistics. Its training loss is therefore in standardized units. evaluate.py transforms predictions and labels back before reporting MAE, RMSE, and R². The baseline always predicts the training-set target mean. A good average score can still conceal a systematic error in one region, so examine residuals and performance across meaningful subgroups.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html

## 10. Classification: logits, probabilities, and labels

Binary classification uses one logit z and a sigmoid probability p=1/(1+exp(−z)). Binary cross entropy is −[y log p+(1−y)log(1−p)]. The implementation evaluates the equivalent stable expression logaddexp(0,z)−yz. The derivative with respect to the logit is p−y, divided by batch size. A default probability threshold of 0.5 is only a starting decision rule. Tune thresholds on validation data when error costs differ.

Multiclass classification means exactly one of K mutually exclusive classes. Softmax normalizes all K logits together. Subtracting the maximum logit before exponentiation preserves the probabilities while preventing overflow. The loss is the negative log-probability of the correct class. The code stores class labels as integer IDs and performs a direct indexed lookup, with no need to store one-hot targets.

Multilabel classification permits several labels per row and uses independent sigmoid probabilities; they need not sum to one. The table explains that distinction, but the delivered CLI supports scalar regression, binary classification, and mutually exclusive multiclass classification. Probability values are model outputs, not automatically calibrated confidence estimates. The metadata records the class order; in the binary demo, 'low' maps to class 1.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html
PyTorch, Optimizing Model Parameters. https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html

## 11. Backpropagation and the chain rule

Backpropagation efficiently applies the chain rule. At each layer, save the input activation and preactivation during the forward pass. Starting with the derivative of the output loss, compute the weight derivative by multiplying the transposed input by δ. Sum δ across examples to obtain the bias derivative. Propagate the derivative through the previous weight matrix, then multiply elementwise by the derivative of the previous activation function. The mean-over-batch factor is already included in the output derivative and must not be divided in again at every layer.

For the numerical example, the chosen half-squared error has derivative ŷ−y=0.05. ReLU is active, so its derivative is 1. Multiplying 0.05 by the inputs gives 0.05 and −0.10. Subtracting 0.1 times each gradient gives the updated parameters. The prediction becomes 0.495+0.480+0.095=1.07, closer to 1.05. The half-squared error falls from 0.00125 to 0.00020.

This hand example uses ½ squared error for simple arithmetic. The harness uses mean squared error without the half, whose derivative is 2(ŷ−y)/B for a scalar output. Unit tests compare every analytical parameter gradient with a central finite difference.

References
Stanford CS231n, Backpropagation. https://cs231n.github.io/optimization-2/

## 12. The training loop

At the start, initialize weights randomly and biases to zero. Identical zero weights throughout the network would preserve symmetry among hidden units, so they would learn identical features. The implementation uses a variance scaled to layer width, with a He-style scale for ReLU hidden layers.

Shuffle the training indices each epoch, then take a minibatch. The forward pass computes outputs using the current parameters. The loss compares those outputs with labels. Backpropagation computes the gradient of that minibatch loss with respect to every parameter. The optimizer then modifies the parameters. New batches repeat the sequence. Gradients describe sensitivity of the current loss; they are not themselves new weights.

After the epoch, score both training and validation sets using the same current checkpoint. This makes the plotted losses directly comparable. The code saves a copy when validation loss improves and stops after a chosen number of epochs without improvement. It restores the best weights at the end. Test data never participates in these choices. In an autograd framework, gradients usually accumulate by default and need to be cleared each step. This NumPy implementation returns fresh gradient arrays on every call.

References
PyTorch, Optimizing Model Parameters. https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html
Stanford CS231n, Neural Networks Part 2. https://cs231n.github.io/neural-networks-2/

## 13. Optimizers turn gradients into parameter updates

Here g is the gradient of the data loss. In SGD with momentum, a running velocity combines the old direction and the current gradient. The momentum μ is 0.9 in the harness. With μ=0 and no weight decay, the update is ordinary gradient descent on each minibatch. The SGD implementation adds an L2 gradient term λW to weights before momentum and does not penalize biases.

Adam keeps exponential averages of gradients and squared gradients. The code uses β1=0.9 and β2=0.999. Because the averages start at zero, divide m by 1−β1^t and v by 1−β2^t to obtain bias-corrected estimates. Divide the corrected first moment by the square root of the corrected second moment plus ε=10^−8. Every operation is elementwise.

AdamW separately shrinks weights by 1−ηλ. That decoupled decay differs from adding an L2 gradient term inside Adam's adaptive moments. The laboratory default is AdamW with η=0.003 and λ=0.0001. These are teaching defaults, not universally optimal values. Optimizers store state as well as parameters. The saved checkpoint in this package supports inference; exact mid-training resumption would also require moments, update count, and random-generator state.

References
Kingma & Ba (2015), Adam: A Method for Stochastic Optimization. https://arxiv.org/abs/1412.6980
Loshchilov & Hutter (2019), Decoupled Weight Decay Regularization. https://arxiv.org/abs/1711.05101

## 14. Learning rate controls the size of each step

For this one-dimensional loss, the derivative is w. Plain gradient descent gives w_next=w−ηw=(1−η)w. Starting at 1, the closed-form loss after t updates is 0.5(1−η)^(2t). A rate of 0.1 reduces the weight slowly. A rate of 0.8 reduces it quickly. A rate of 2.1 alternates sign while growing in magnitude. Convergence for this particular quadratic requires 0<η<2. That numerical boundary is not a rule for general neural networks.

An MLP has many interacting parameters and directions with different curvature. Minibatches add noise and adaptive optimizers rescale coordinates, so there is no single universal safe learning rate. Standardize inputs before interpreting learning-rate behavior. Compare a small logarithmic grid such as 0.0003, 0.001, 0.003, and 0.01 using the same training/validation split and a fresh initialization. Save each experiment in a separate directory.

A schedule can reduce the learning rate after a plateau or gradually over training. The provided harness intentionally uses a constant rate to keep the experiment interpretable. Numerical divergence is an error condition, not a useful test score. The code rejects nonfinite losses and gradients.

References
Kingma & Ba (2015), Adam: A Method for Stochastic Optimization. https://arxiv.org/abs/1412.6980

## 15. Batches, steps, and epochs

With 1,680 training rows and batch size 64, twenty-six batches contain 1,664 examples, leaving sixteen for the final batch. The harness includes that partial batch instead of silently discarding it. There are therefore twenty-seven updates per epoch and 2,700 updates across one hundred full epochs. Early stopping can reduce the actual number.

Full-batch gradient descent uses every training row for each update. Stochastic gradient descent in the strict sense uses one row, though practitioners often use SGD to include minibatch training. Minibatches estimate the training gradient using a subset. Averaging the loss within each batch keeps its scale from growing directly with batch size. The final smaller batch also uses its own row count.

Shuffle training rows between epochs so fixed ordering does not repeatedly bias successive updates. Validation and test evaluation need no shuffling for correctness. Their metrics should weight examples, not give equal weight to an incomplete batch. The provided harness computes complete-set losses directly at epoch boundaries. On much larger datasets, implement a weighted accumulation over evaluation batches. Increasing batch size reduces the number of steps per epoch, so compare experiments in both epochs and optimizer steps.

References
PyTorch, Optimizing Model Parameters. https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html

## 16. The model in executable NumPy

Read mlp.py alongside the equations on slide 6. MLP constructs a dictionary of weight matrices and bias rows. The forward method multiplies the current activations by each weight matrix, adds a bias, and applies the hidden activation. The final layer remains linear. When cache=True, it saves the previous activation and current preactivation for each layer.

The loss_grad method obtains the loss derivative with respect to final logits or values, then traverses the layers in reverse. The code shown here is an excerpt of those operations, not a standalone script: W, b, and dz refer to one layer. The actual function multiplies da_prev by the previous activation derivative before continuing backward. ReLU uses prev_z>0, while tanh uses 1−tanh(prev_z)^2.

Data types and encoding stay in data.py, which makes the mathematical code easier to audit. NumPy uses CPU execution and float64 arrays in this package. A library such as PyTorch can replace explicit differentiation with autograd and move tensors to accelerators, while preserving these shape and loss conventions. This package does not claim to provide a GPU backend.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html
Stanford CS231n, Backpropagation. https://cs231n.github.io/optimization-2/

## 17. A complete training and validation harness

train.py loads the CSV and schema, constructs deterministic splits, and fits both feature and target transformations only on training rows. It then builds an MLP whose input width is the actual encoded feature count. The hidden sizes, activation, optimizer, learning rate, weight decay, batch size, seed, and epoch limit are command-line arguments.

The displayed loop is a short excerpt. The full fit function tracks the lowest validation loss, copies the associated weights, counts epochs without improvement, and restores the best weights before returning. Its default patience is twenty-five epochs. Validation improvements must exceed 10^−8 to reset patience. The training and validation curves are data losses; decoupled weight decay is not added to those plotted values.

The run directory stores compressed numerical weights, metadata, and CSV learning curves. Metadata includes feature ordering, preprocessing statistics, class names or target scaling, architecture, split indices, data hash, software versions, and the best epoch. A nonempty output directory is rejected to protect previous experiments. The snapshot is intended for inference and evaluation. Optimizer moments and generator state are not saved, so it is not an exact-resume training checkpoint.

References
PyTorch, Optimizing Model Parameters. https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html
scikit-learn, Common pitfalls and recommended practices. https://scikit-learn.org/stable/common_pitfalls.html

## 18. Held-out testing: measured results

Data generation uses seed 42 and creates 2,400 rows per task. Each row contains two numerical features, a Boolean catalyst indicator, and a material category. Artificial nonlinear equations generate the labels, and two percent of values in each input column are missing. These results demonstrate the software on a controlled exercise and are not a scientific benchmark or a claim about physical materials.

The three-class MLP uses widths 11,32,16,3, ReLU, AdamW at learning rate 0.003, batch size 64, and weight decay 0.0001. Validation selects epoch 44. The separate test harness evaluates 363 test rows and obtains 94.49% accuracy and macro-F1 0.930. Its training-majority baseline obtains 48.21% accuracy. The learning curves show every completed epoch, including training after the selected checkpoint; the tested weights are restored to epoch 44.

The regression MLP uses one output and selects epoch 76. On 360 test rows it obtains RMSE 1.904, MAE 1.031, and R² 0.947. The training-mean baseline has RMSE 8.326. The scatterplot shows all test predictions in original response units. The separate binary example reaches 96.40% accuracy on 361 test rows. Run logs, predictions, and confusion matrices accompany the code.

References


## 19. Diagnostics, regularization, and tests

Diagnose the shape of the problem before changing many settings at once. If a small network cannot overfit a tiny clean batch, inspect target alignment, shapes, activation behavior, and gradient calculations. If both losses remain high, the model might lack capacity or the optimization might be inadequate. If the training loss keeps improving while validation degrades, choose an earlier checkpoint and consider stronger regularization or better data coverage.

Weight decay discourages large weights, while early stopping limits fitting to the training set. Dropout randomly masks activations during training and changes behavior during evaluation; it is discussed as an extension and is not implemented in this minimal code. Neither regularization nor a more powerful network can fix leaked data or systematically wrong labels.

The ten unit tests include finite-difference gradient checks for regression, binary, and multiclass losses under both ReLU and tanh; stability at extreme logits; a hand-calculated SGD update; bias exclusion from AdamW decay; training-only preprocessing; split integrity; label rejection; checkpoint roundtrips; XOR fitting; and regression/classification learning. A gradient test catches calculus or indexing errors, while held-out metrics test predictive behavior. Both are necessary and answer different questions.

References
Stanford CS231n, Neural Networks Part 2. https://cs231n.github.io/neural-networks-2/
Stanford CS231n, Backpropagation. https://cs231n.github.io/optimization-2/

## 20. Laboratory and further reading

Create a Python virtual environment, install the single dependency from requirements.txt, and run run_all.py from the extracted package. The runner generates data, executes tests, fits XOR, trains three supervised tasks, scores each held-out test set, and predicts two unlabeled examples. It uses local CPU execution and requires no network after NumPy is installed. The package includes reference_runs with the results used in the slides. New runs go into runs, leaving the reference results available for comparison. A repeat run into the same nonempty output directory intentionally stops; choose new directories for additional experiments.

Read README.md for the exact train, evaluate, and predict commands and the JSON schema format. Read lecture_notes.md for a slide-by-slide explanation. For controlled comparisons, keep the data split fixed and change one setting at a time. Record validation performance before looking at test performance. If you try many configurations, reserve fresh test data for a final evaluation.

Suggested exercises are to verify the thirteen-parameter network count on slide 5, derive the binary-loss gradient p−y, deliberately fit preprocessing on held-out data to understand why it is invalid without using that result as a score, and implement dropout with distinct train/evaluation behavior. All reference links below are included in the notes.

References
Goodfellow, Bengio & Courville (2016), Deep Learning, Ch. 6. https://www.deeplearningbook.org/contents/mlp.html
Stanford CS231n, Neural Networks Part 1. https://cs231n.github.io/neural-networks-1/
Stanford CS231n, Neural Networks Part 2. https://cs231n.github.io/neural-networks-2/
Stanford CS231n, Backpropagation. https://cs231n.github.io/optimization-2/
Kingma & Ba (2015), Adam: A Method for Stochastic Optimization. https://arxiv.org/abs/1412.6980
Loshchilov & Hutter (2019), Decoupled Weight Decay Regularization. https://arxiv.org/abs/1711.05101
scikit-learn, Common pitfalls and recommended practices. https://scikit-learn.org/stable/common_pitfalls.html
PyTorch, Optimizing Model Parameters. https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html