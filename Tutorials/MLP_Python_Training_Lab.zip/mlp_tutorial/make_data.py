"""Generate synthetic scientific-style tabular problems; no downloads required."""
import csv
from pathlib import Path
import argparse
import numpy as np
from data import write_json


def generate(out, n=2400, seed=42):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    temp = rng.uniform(250, 750, n)
    pressure = rng.uniform(1, 10, n)
    catalyst = rng.integers(0, 2, n)
    material = rng.choice(['A', 'B', 'C'], n)
    a, b = (temp-500)/150, (pressure-5.5)/3
    offset = np.array([{'A':-.6, 'B':0, 'C':.6}[m] for m in material])
    # Deliberately nonlinear, artificial relations. These are not physical laws.
    response = 30 + 10*np.sin(a) + 3*b*b + 5*catalyst + 4*offset + rng.normal(0, .8, n)
    scores = np.column_stack([1.2*a-.7*b+.8*catalyst, -a+.8*b+offset, .7*a*b-.8*catalyst-offset])
    label = np.array(['phase_A', 'phase_B', 'phase_C'])[np.argmax(scores+rng.normal(0, .12, scores.shape), axis=1)]
    binary = np.where(response > 35, 'high', 'low')
    rows = []
    for i in range(n):
        rows.append(dict(temperature=f'{temp[i]:.5f}', pressure=f'{pressure[i]:.5f}',
            catalyst='true' if catalyst[i] else 'false', material=material[i]))
    # A little missing input data demonstrates imputation and missingness flags.
    for name in ('temperature', 'pressure', 'catalyst', 'material'):
        for i in rng.choice(n, int(.02*n), replace=False):
            rows[i][name] = ''
    features = dict(temperature='numeric', pressure='numeric', catalyst='boolean', material='categorical')
    for task, labels in [('classification', label), ('regression', response), ('binary', binary)]:
        with open(out/f'{task}.csv', 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=[*features, 'target'])
            writer.writeheader()
            writer.writerows([{**r, 'target': y} for r, y in zip(rows, labels)])
        write_json(out/f'{task}_schema.json', dict(features=features, target='target', task=task))
    with open(out/'unlabeled.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(features))
        writer.writeheader()
        writer.writerows([dict(temperature='520', pressure='3', catalyst='true', material='A'),
                          dict(temperature='', pressure='7', catalyst='false', material='NEW')])


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', default='data')
    p.add_argument('--n', type=int, default=2400)
    p.add_argument('--seed', type=int, default=42)
    a = p.parse_args()
    generate(a.out, a.n, a.seed)
