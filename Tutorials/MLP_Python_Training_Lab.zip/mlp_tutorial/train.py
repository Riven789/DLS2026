"""Train and validate. The test split is saved but is never scored here."""
import argparse
import csv
import json
from pathlib import Path
import platform
import numpy as np
from data import Preprocessor, read_csv, validate_schema, split_rows, fit_target, encode_target, file_hash, write_json
from mlp import MLP, Optimizer


def fit(model, x, y, xv, yv, task, epochs=150, batch_size=64, lr=.003,
        optimizer='adamw', weight_decay=1e-4, patience=25, seed=7):
    if min(epochs, batch_size, patience) < 1:
        raise ValueError('epochs, batch size, patience must be positive.')
    opt = Optimizer(model.params, optimizer, lr, weight_decay)
    rng = np.random.default_rng(seed)
    best_loss, best_epoch, bad_epochs = float('inf'), 0, 0
    best = {k: v.copy() for k, v in model.params.items()}
    history = []
    for epoch in range(1, epochs+1):
        order = rng.permutation(len(x))
        for start in range(0, len(x), batch_size):
            batch = order[start:start+batch_size]  # includes final partial batch
            loss, grads = model.loss_grad(x[batch], y[batch], task)
            if not np.isfinite(loss):
                raise FloatingPointError('Nonfinite loss. Try a smaller learning rate.')
            opt.step(model.params, grads)
        # Same checkpoint for train and validation curves, data losses only.
        train_loss = model.loss(x, y, task)
        val_loss = model.loss(xv, yv, task)
        if not np.isfinite(train_loss) or not np.isfinite(val_loss):
            raise FloatingPointError('Nonfinite epoch loss.')
        history.append(dict(epoch=epoch, train_loss=train_loss, val_loss=val_loss, lr=lr))
        if val_loss < best_loss - 1e-8:
            best_loss, best_epoch, bad_epochs = val_loss, epoch, 0
            best = {k: v.copy() for k, v in model.params.items()}
        else:
            bad_epochs += 1
        if bad_epochs >= patience:
            break
    for k in model.params:
        model.params[k][...] = best[k]
    return history, best_epoch


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', required=True)
    p.add_argument('--schema', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--hidden', type=int, nargs='+', default=[32, 16])
    p.add_argument('--activation', choices=['relu', 'tanh'], default='relu')
    p.add_argument('--optimizer', choices=['sgd', 'adamw'], default='adamw')
    p.add_argument('--lr', type=float, default=.003)
    p.add_argument('--weight-decay', type=float, default=1e-4)
    p.add_argument('--epochs', type=int, default=150)
    p.add_argument('--batch-size', type=int, default=64)
    p.add_argument('--patience', type=int, default=25)
    p.add_argument('--seed', type=int, default=7)
    args = p.parse_args()
    out = Path(args.out)
    if out.exists() and any(out.iterdir()):
        p.error('Output directory is nonempty. Choose a new run directory.')
    rows = read_csv(args.csv)
    schema = json.loads(Path(args.schema).read_text())
    validate_schema(schema, rows)
    split = split_rows(rows, schema, args.seed)
    train_rows, val_rows = ([rows[i] for i in split[k]] for k in ('train', 'val'))
    pre = Preprocessor().fit(train_rows, schema['features'])
    target = fit_target(train_rows, schema)
    x, xv = pre.transform(train_rows), pre.transform(val_rows)
    y, yv = encode_target(train_rows, schema, target), encode_target(val_rows, schema, target)
    output_dim = len(target['classes']) if schema['task'] == 'classification' else 1
    model = MLP([x.shape[1], *args.hidden, output_dim], args.activation, args.seed)
    history, best_epoch = fit(model, x, y, xv, yv, schema['task'], args.epochs,
        args.batch_size, args.lr, args.optimizer, args.weight_decay, args.patience, args.seed)
    out.mkdir(parents=True, exist_ok=True)
    model.save(out/'weights.npz')
    baseline = dict(value=float(y.mean())) if schema['task'] == 'regression' else dict(class_index=int(np.bincount(y.astype(int).ravel()).argmax()))
    metadata = dict(schema=schema, preprocessing=pre.state, target=target, sizes=model.sizes,
        activation=args.activation, split=split, csv_sha256=file_hash(args.csv),
        feature_names=pre.names(), config=vars(args), best_epoch=best_epoch,
        baseline=baseline, versions=dict(python=platform.python_version(), numpy=np.__version__))
    write_json(out/'metadata.json', metadata)
    with open(out/'history.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    print(json.dumps(dict(best_epoch=best_epoch, best_val_loss=history[best_epoch-1]['val_loss'],
        parameters=sum(v.size for v in model.params.values()), split_sizes={k: len(v) for k, v in split.items()}), indent=2))


if __name__ == '__main__':
    main()
