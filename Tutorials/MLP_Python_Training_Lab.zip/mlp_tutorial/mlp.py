"""A small dense neural network: explicit forward pass, backprop, SGD and AdamW.
All examples use rows for samples: X is [batch, features], W is [in, out].
"""
import numpy as np


def sigmoid(z):
    # This form avoids exp(large positive) for either sign of z.
    return np.exp(-np.logaddexp(0.0, -z))


def softmax(z):
    e = np.exp(z - z.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


def loss_and_gradient(z, y, task):
    """Mean data loss and its derivative with respect to output logits/values."""
    n = len(y)
    if task == 'regression':
        error = z - y
        return float(np.mean(error ** 2)), 2 * error / error.size
    if task == 'binary':
        # BCE = softplus(z) - y*z; sigmoid is fused into the loss.
        loss = np.mean(np.logaddexp(0.0, z) - y * z)
        return float(loss), (sigmoid(z) - y) / y.size
    if task == 'classification':
        shifted = z - z.max(axis=1, keepdims=True)
        logp = shifted - np.log(np.exp(shifted).sum(axis=1, keepdims=True))
        loss = -logp[np.arange(n), y].mean()
        dz = np.exp(logp)
        dz[np.arange(n), y] -= 1
        return float(loss), dz / n
    raise ValueError(f'Unknown task: {task}')


class MLP:
    def __init__(self, sizes, activation='relu', seed=7):
        if len(sizes) < 2 or any(v <= 0 for v in sizes):
            raise ValueError('Layer sizes must be positive; include input and output.')
        if activation not in ('relu', 'tanh'):
            raise ValueError('Hidden activation must be relu or tanh.')
        self.sizes, self.activation = list(sizes), activation
        rng = np.random.default_rng(seed)
        self.params = {}
        for i, (nin, nout) in enumerate(zip(sizes[:-1], sizes[1:])):
            scale = np.sqrt((2 if activation == 'relu' and i < len(sizes)-2 else 1) / nin)
            self.params[f'W{i}'] = rng.normal(0, scale, (nin, nout))
            self.params[f'b{i}'] = np.zeros((1, nout))

    def forward(self, x, cache=False):
        """Output layer is always linear. Loss/prediction applies sigmoid/softmax."""
        a, saved = x, []
        depth = len(self.sizes) - 1
        for i in range(depth):
            z = a @ self.params[f'W{i}'] + self.params[f'b{i}']
            saved.append((a, z))
            a = z if i == depth-1 else (np.maximum(z, 0) if self.activation == 'relu' else np.tanh(z))
        return (a, saved) if cache else a

    def loss(self, x, y, task):
        return loss_and_gradient(self.forward(x), y, task)[0]

    def loss_grad(self, x, y, task):
        z, saved = self.forward(x, cache=True)
        loss, dz = loss_and_gradient(z, y, task)
        grads = {}
        # The loss gradient already includes the mean-over-batch factor.
        for i in reversed(range(len(saved))):
            a_prev, _ = saved[i]
            grads[f'W{i}'] = a_prev.T @ dz
            grads[f'b{i}'] = dz.sum(axis=0, keepdims=True)
            if i > 0:
                da = dz @ self.params[f'W{i}'].T
                prev_z = saved[i-1][1]
                derivative = (prev_z > 0) if self.activation == 'relu' else 1 - np.tanh(prev_z)**2
                dz = da * derivative
        return loss, grads

    def save(self, path):
        np.savez_compressed(path, **self.params)

    def load(self, path):
        with np.load(path, allow_pickle=False) as values:
            for key in self.params:
                if values[key].shape != self.params[key].shape:
                    raise ValueError(f'Checkpoint shape mismatch for {key}')
                self.params[key][...] = values[key]
        return self


class Optimizer:
    """SGD with momentum, or AdamW with decoupled decay on weights only."""
    def __init__(self, params, name='adamw', lr=0.003, weight_decay=1e-4, momentum=0.9):
        if name not in ('sgd', 'adamw') or lr <= 0 or weight_decay < 0:
            raise ValueError('Invalid optimizer configuration')
        self.name, self.lr, self.weight_decay, self.momentum = name, lr, weight_decay, momentum
        self.m = {k: np.zeros_like(v) for k, v in params.items()}
        self.v = {k: np.zeros_like(v) for k, v in params.items()}
        self.t = 0

    def step(self, params, grads):
        if any(not np.isfinite(g).all() for g in grads.values()):
            raise FloatingPointError('Nonfinite gradient. Check input scaling and learning rate.')
        self.t += 1
        for k, p in params.items():
            g = grads[k]
            if self.name == 'sgd':
                # Classical L2 penalty for SGD. Biases are excluded.
                g = g + self.weight_decay * p if k.startswith('W') else g
                self.m[k] = self.momentum * self.m[k] + g
                p -= self.lr * self.m[k]
            else:
                self.m[k] = 0.9 * self.m[k] + 0.1 * g
                self.v[k] = 0.999 * self.v[k] + 0.001 * g**2
                mhat = self.m[k] / (1 - 0.9**self.t)
                vhat = self.v[k] / (1 - 0.999**self.t)
                if k.startswith('W'):
                    p *= 1 - self.lr * self.weight_decay
                p -= self.lr * mhat / (np.sqrt(vhat) + 1e-8)
