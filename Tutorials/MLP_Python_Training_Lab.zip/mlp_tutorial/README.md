# Multilayer perceptron tutorial laboratory

A complete, inspectable Python/NumPy implementation for a 20-slide undergraduate tutorial. It exposes the forward pass, backpropagation, SGD with momentum, and AdamW. It includes data preparation, training/validation, held-out testing, saved-model inference, synthetic data, and ten unit tests.

**Runs on a CPU.** No GPU backend, external dataset, or API key is required. Dependencies: Python 3.10+ and NumPy. Tested with Python 3.12 and NumPy 2.3.5. Small floating-point differences can occur with other BLAS libraries. The mathematical explanations are in `lecture_notes.md` and the PowerPoint speaker notes.

## Quick start

Open a terminal in this extracted directory:

```bash
python -m venv .venv
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run_all.py
```

This creates synthetic data, runs the tests, fits XOR, trains regression and two classification models, evaluates the frozen models, and predicts new rows. An existing nonempty run directory is rejected to avoid overwriting an experiment. For a repeat experiment, use the separate commands below with a fresh `--out` path. Results shown in the slides are preserved in `reference_runs/`; new results go in `runs/`.

The included scientific-style examples are artificial teaching datasets. They do not model validated physical laws or establish scientific predictive performance.

## Files and teaching purpose

| File | Purpose |
|---|---|
| `mlp.py` | Dense model, explicit derivatives, stable losses, SGD/AdamW |
| `data.py` | Explicit feature types, train-only transforms, labels and splits |
| `make_data.py` | Reproducible synthetic CSV data and schema generation |
| `train.py` | Minibatches, validation, early stopping, best checkpoint |
| `evaluate.py` | Separate test scoring, baseline, confusion matrices |
| `predict.py` | Inference on unlabeled CSV rows using saved transforms |
| `xor_demo.py` | Fitting the four Boolean XOR cases with tanh hidden units |
| `tests/test_mlp.py` | Gradient, numerical stability, data, and learning checks |
| `run_all.py` | One-command lab harness |
| `lecture_notes.md` | Detailed explanations for all 20 slides |
| `reference_runs/` | Weights, metadata, learning curves, and measured results |

## Training one task

```bash
python make_data.py --out data
python train.py --csv data/classification.csv \
  --schema data/classification_schema.json --out runs/classification \
  --hidden 32 16 --activation relu --optimizer adamw \
  --lr 0.003 --weight-decay 0.0001 --batch-size 64 \
  --epochs 150 --patience 25 --seed 7

python evaluate.py --csv data/classification.csv --run runs/classification
python predict.py --csv data/unlabeled.csv --run runs/classification \
  --out runs/classification/new_predictions.csv
```

For regression or binary classification, substitute `regression` or `binary` in the data/schema/run paths. The schema determines the output and loss. The `train.py --help` command lists all options. The CPU code uses float64 and may benefit from `OPENBLAS_NUM_THREADS=1` for these tiny matrices; high thread counts can slow small models.

## Your own labeled CSV

Prepare one row per independent example. Include a header and a target column. Example:

```csv
temperature,pressure,catalyst,material,target
520,3,true,A,phase_A
430,7,false,B,phase_B
610,5,true,C,phase_C
```

These three rows illustrate the format only; they are too few to train/evaluate. Create a JSON schema:

```json
{
  "features": {
    "temperature": "numeric",
    "pressure": "numeric",
    "catalyst": "boolean",
    "material": "categorical"
  },
  "target": "target",
  "task": "classification"
}
```

Supported tasks are `classification` (one of K classes), `binary` (exactly two classes), and `regression` (one real-valued target). The lecture explains multilabel classification, but the CLI does not implement multilabel targets. There is no final output activation inside the MLP. The loss operates on raw logits/values and prediction applies the appropriate transform.

### Input handling

- Numerical features: impute a training median, standardize with the training mean and population standard deviation, and append a missingness flag.
- Boolean features: parse `true/false`, `yes/no`, or `1/0`, case insensitive. Missing entries use the training majority plus a missingness flag. Ambiguous values raise an error.
- Categorical features: one-hot encode a training vocabulary with separate missing and unknown positions. Unknown values preserve input shape; they do not guarantee good predictions.
- Missing tokens: empty string, `NA`, `NaN`, `null`, `none`, and `?` (case insensitive). These tokens are reserved, including in categorical columns and labels. Rename a genuine category with one of those spellings before use.
- Numeric infinities and entirely missing training features raise an error. Invalid numeric strings raise an error.
- Features follow the explicit JSON order. IDs, split membership, and post-outcome measurements should not be features. The target and split column cannot be listed as features.
- No automatic ordinal encoding, logarithmic transformation, text tokenization, embeddings, date engineering, or domain-specific unit conversion is performed. Add scientifically justified transforms before running the lab and preserve their definitions for inference.

### Labels

Every training/validation/test row needs a label. Missing labels raise an error. Classification names are sorted from training data into a stable ID mapping. Binary class 1 is the second stored name, so inspect `metadata.json` before interpreting the sigmoid output as a particular event. In the supplied binary example the class order is `["high", "low"]`; the sigmoid gives P(low). Predictions include separately named probabilities for both classes.

Regression targets are standardized using training statistics, and evaluate/predict invert that transform to report original units. Predictions require only feature columns. An unknown evaluation class is an error rather than a silent relabeling.

### Independent, grouped, and chronological splits

The default split is approximately 70/15/15, with class stratification for classification and integer rounding per class. It requires at least seven rows per class (or seven rows total for regression), but that minimum is not enough for a useful real experiment. Fixed seeds reproduce the split.

Random splitting assumes independent rows. For repeated measurements, subjects, batches, or forecasting, assign the split yourself. Add a column such as `partition` containing `train`, `val`, or `test`, and add `"split_column": "partition"` to the schema. Keep all rows from a group together, or use past rows for training and future rows for evaluation. The harness honors these assignments; it does not check domain-specific group/time leakage. Each split must be nonempty, and training must contain every class evaluated later.

Preprocessing and target statistics use training rows only. Validation selects settings and epochs. Test metrics should be inspected only after those choices are fixed. The original data hash protects saved row-index assignments: `evaluate.py` refuses a changed CSV. Use `predict.py` for different or unlabeled files.

## Reading the implementation

The batch convention is `[B, input_width]`. Each weight matrix is `[input_width, output_width]`. Thus `z = a @ W + b` broadcasts a `[1, output_width]` bias over B rows. ReLU/tanh apply elementwise in hidden layers. Weights start randomly at a width-dependent scale; biases start at zero.

`loss_and_gradient` supplies the output derivative. The mean factor appears once at the output, then backprop applies the chain rule to earlier layers. For regression, the loss is mean squared error (without a factor of one half). Binary and multiclass losses use stable logit formulas. `loss_grad` returns fresh gradients, so there is no persistent gradient buffer to clear.

AdamW decays weight matrices only, with default β1=0.9, β2=0.999, ε=1e-8. SGD uses momentum 0.9 and adds an L2 gradient term on weights only. The two implementations intentionally follow their different weight-decay semantics. Learning rate is constant in this teaching harness. Dropout and learning-rate schedules are exercises rather than implemented features.

The full epoch curves evaluate all training and validation rows at the same weights. Early stopping restores the lowest-validation-loss checkpoint. Saved weights are for inference, **not exact training resumption**: optimizer moments, update counter, and generator state would also need to be saved to resume exactly.

## Measured reference results

Generator seed 42, model/split seed 7, 2,400 rows, 2% missing values per input column. Architecture is 11–32–16–K, ReLU, AdamW, learning rate 0.003, weight decay 0.0001, batch size 64, at most 150 epochs, patience 25. A test set is held out separately for each task.

| Task | Best epoch | Test rows | Model | Training-only baseline |
|---|---:|---:|---|---|
| Three classes | 44 | 363 | accuracy 0.9449, macro-F1 0.9300 | majority accuracy 0.4821 |
| Regression | 76 | 360 | MAE 1.0314, RMSE 1.9042, R² 0.9474 | mean RMSE 8.3257 |
| Binary | 23 | 361 | accuracy 0.9640, macro-F1 0.9640 | majority accuracy 0.5125 |

The classification confusion matrix uses actual classes as rows and predicted classes as columns, ordered phase_A, phase_B, phase_C:

```text
169   4   2
  4 130   3
  5   2  44
```

XOR fits all four training cases correctly with probabilities approximately 0.000058, 0.999963, 0.999947, and 0.000023. Because all cases train the network, that result is a demonstration of fitting, not a generalization estimate.

## Tests and experiments

```bash
python -m unittest discover -s tests -v
python xor_demo.py
```

Ten tests cover finite-difference derivatives for all three tasks and both hidden activations, stable extreme logits, a hand-calculated update, optimizer decay semantics, train-only preprocessing, split integrity, label rejection, checkpoint round trips, XOR fitting, and learning on regression and classification examples.

Suggested extensions: a linear baseline, explicit learning-rate schedules, dropout with training/evaluation modes, multilabel outputs, robust regression loss, and group-aware splitting. Try one change at a time. Use new run directories and keep the original split fixed for validation comparisons. Do not repeatedly select models based on test performance.

## References

- Goodfellow, Bengio, Courville. *Deep Learning*, Chapter 6: https://www.deeplearningbook.org/contents/mlp.html
- Stanford CS231n, neural networks: https://cs231n.github.io/neural-networks-1/
- Stanford CS231n, data and regularization: https://cs231n.github.io/neural-networks-2/
- Stanford CS231n, backpropagation: https://cs231n.github.io/optimization-2/
- Kingma and Ba. *Adam: A Method for Stochastic Optimization* (2015): https://arxiv.org/abs/1412.6980
- Loshchilov and Hutter. *Decoupled Weight Decay Regularization* (2019): https://arxiv.org/abs/1711.05101
- scikit-learn, leakage guidance: https://scikit-learn.org/stable/common_pitfalls.html
- PyTorch training loop, for comparison with an autograd framework: https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html
