"""Score a frozen checkpoint on the held-out test rows, with baseline comparison."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from data import Preprocessor, read_csv, encode_target, file_hash, write_json
from mlp import MLP, sigmoid, softmax


def load_run(run):
    run = Path(run)
    meta = json.loads((run/'metadata.json').read_text())
    model = MLP(meta['sizes'], meta['activation']).load(run/'weights.npz')
    return model, meta, Preprocessor(meta['preprocessing'])


def metrics(y, pred, task, num_classes=None):
    if task == 'regression':
        err = np.asarray(pred).ravel() - np.asarray(y).ravel()
        denom = float(np.sum((np.asarray(y).ravel()-np.mean(y))**2))
        return dict(mae=float(np.mean(abs(err))), rmse=float(np.sqrt(np.mean(err**2))),
                    r2=float(1 - np.sum(err**2)/denom) if denom > 0 else None)
    y, pred = np.asarray(y, int).ravel(), np.asarray(pred, int).ravel()
    cm = np.zeros((num_classes, num_classes), dtype=int)
    np.add.at(cm, (y, pred), 1)
    tp = np.diag(cm)
    precision = np.divide(tp, cm.sum(0), out=np.zeros(num_classes), where=cm.sum(0)>0)
    recall = np.divide(tp, cm.sum(1), out=np.zeros(num_classes), where=cm.sum(1)>0)
    f1 = np.divide(2*precision*recall, precision+recall, out=np.zeros(num_classes), where=precision+recall>0)
    return dict(accuracy=float(np.mean(y == pred)), macro_f1=float(f1.mean()),
                precision=precision.tolist(), recall=recall.tolist(), confusion_matrix=cm.tolist())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', required=True)
    p.add_argument('--run', required=True)
    args = p.parse_args()
    model, meta, pre = load_run(args.run)
    if file_hash(args.csv) != meta['csv_sha256']:
        p.error('CSV changed. Test row indices apply only to the original dataset.')
    rows = read_csv(args.csv)
    ids = meta['split']['test']
    test = [rows[i] for i in ids]
    x = pre.transform(test)
    y = encode_target(test, meta['schema'], meta['target'])
    task = meta['schema']['task']
    z = model.forward(x)
    if task == 'regression':
        y = y * meta['target']['scale'] + meta['target']['mean']
        pred = z * meta['target']['scale'] + meta['target']['mean']
        base = np.full_like(y, meta['baseline']['value']*meta['target']['scale']+meta['target']['mean'])
        nclasses = None
    else:
        pred = (sigmoid(z).ravel() >= .5).astype(int) if task == 'binary' else z.argmax(1)
        nclasses = len(meta['target']['classes'])
        base = np.full(len(y), meta['baseline']['class_index'])
    result = dict(n_test=len(y), best_epoch=meta['best_epoch'],
        model=metrics(y, pred, task, nclasses), baseline=metrics(y, base, task, nclasses))
    if task != 'regression':
        result['class_order'] = meta['target']['classes']
    write_json(Path(args.run)/'test_metrics.json', result)
    with open(Path(args.run)/'test_predictions.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['row_index', 'actual', 'predicted'])
        writer.writerows(zip(ids, y.ravel().tolist(), np.asarray(pred).ravel().tolist()))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
