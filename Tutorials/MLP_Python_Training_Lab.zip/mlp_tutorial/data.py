"""Train-only preprocessing, explicit schema, supervised labels, fixed splits."""
import csv
import hashlib
import json
import numpy as np

MISSING = {'', 'na', 'nan', 'null', 'none', '?'}


def read_csv(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError('CSV needs distinct column names.')
        rows = list(reader)
    if not rows or any(None in r or None in r.values() for r in rows):
        raise ValueError('Empty CSV or malformed row.')
    return rows


def file_hash(path):
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def missing(value):
    return str(value).strip().lower() in MISSING


def number(value):
    if missing(value):
        return np.nan
    v = float(value)
    if not np.isfinite(v):
        raise ValueError('Infinite numeric value is not allowed.')
    return v


def boolean(value):
    if missing(value):
        return np.nan
    token = str(value).strip().lower()
    if token in ('true', 'yes', '1'):
        return 1.0
    if token in ('false', 'no', '0'):
        return 0.0
    raise ValueError(f'Invalid Boolean value: {value!r}')


def validate_schema(schema, rows):
    features = schema['features']
    if not features or schema['target'] in features:
        raise ValueError('Specify features explicitly and exclude the target.')
    if schema.get('split_column') in features:
        raise ValueError('Split column must not be a feature.')
    if schema['task'] not in ('regression', 'binary', 'classification'):
        raise ValueError('Task must be regression, binary or classification.')
    if any(v not in ('numeric', 'boolean', 'categorical') for v in features.values()):
        raise ValueError('Feature type must be numeric, boolean or categorical.')
    for name in list(features) + [schema['target']]:
        if name not in rows[0]:
            raise ValueError(f'Missing column: {name}')


class Preprocessor:
    def __init__(self, state=None):
        self.state = state or {}

    def fit(self, rows, features):
        self.state = {}
        for name, kind in features.items():
            values = [r[name] for r in rows]
            if kind in ('numeric', 'boolean'):
                a = np.array([(number if kind == 'numeric' else boolean)(v) for v in values])
                good = a[np.isfinite(a)]
                if len(good) == 0:
                    raise ValueError(f'All training values missing in {name}')
                fill = float(np.median(good)) if kind == 'numeric' else float(good.mean() >= 0.5)
                filled = np.where(np.isnan(a), fill, a)
                mean = float(filled.mean()) if kind == 'numeric' else 0.0
                scale = float(filled.std()) if kind == 'numeric' else 1.0
                self.state[name] = dict(kind=kind, fill=fill, mean=mean, scale=max(scale, 1e-12))
            else:
                # Columns 0 and 1 are missing and unknown. Vocabulary uses train only.
                vocab = sorted({str(v) for v in values if not missing(v)})
                self.state[name] = dict(kind=kind, vocabulary=vocab)
        return self

    def transform(self, rows):
        blocks = []
        for name, state in self.state.items():
            if any(name not in row for row in rows):
                raise ValueError(f'Missing input column: {name}')
            values = [r[name] for r in rows]
            if state['kind'] in ('numeric', 'boolean'):
                fn = number if state['kind'] == 'numeric' else boolean
                a = np.array([fn(v) for v in values])
                miss = np.isnan(a)
                a = (np.where(miss, state['fill'], a) - state['mean']) / state['scale']
                blocks.append(np.column_stack([a, miss.astype(float)]))
            else:
                vocab = {v: i+2 for i, v in enumerate(state['vocabulary'])}
                a = np.zeros((len(rows), len(vocab)+2))
                for i, value in enumerate(values):
                    a[i, 0 if missing(value) else vocab.get(str(value), 1)] = 1.0
                blocks.append(a)
        return np.concatenate(blocks, axis=1)

    def names(self):
        out = []
        for name, state in self.state.items():
            if state['kind'] in ('numeric', 'boolean'):
                out.extend([name, name+'__missing'])
            else:
                out.extend([name+'__missing', name+'__unknown'] + [name+'='+v for v in state['vocabulary']])
        return out


def fit_target(rows, schema):
    values = [r[schema['target']] for r in rows]
    if any(missing(v) for v in values):
        raise ValueError('Supervised training requires a label on every row.')
    if schema['task'] == 'regression':
        y = np.array([number(v) for v in values])
        return dict(mean=float(y.mean()), scale=max(float(y.std()), 1e-12))
    classes = sorted(set(values))
    if len(classes) < 2 or (schema['task'] == 'binary' and len(classes) != 2):
        raise ValueError('Classification needs at least two classes; binary needs exactly two.')
    return dict(classes=classes)


def encode_target(rows, schema, state):
    values = [r[schema['target']] for r in rows]
    if any(missing(v) for v in values):
        raise ValueError('Missing label. Use predict.py for unlabeled data.')
    if schema['task'] == 'regression':
        return ((np.array([number(v) for v in values]) - state['mean']) / state['scale']).reshape(-1, 1)
    lookup = {v: i for i, v in enumerate(state['classes'])}
    if any(v not in lookup for v in values):
        raise ValueError('Label outside the training class vocabulary.')
    y = np.array([lookup[v] for v in values], dtype=int)
    return y.astype(float).reshape(-1, 1) if schema['task'] == 'binary' else y


def split_rows(rows, schema, seed=7):
    """70/15/15 per class (or globally for regression), unless split is explicit.
    Random splitting assumes independent rows. Use a split column for group/time data.
    """
    rng = np.random.default_rng(seed)
    result = {k: [] for k in ('train', 'val', 'test')}
    if schema.get('split_column'):
        for i, row in enumerate(rows):
            part = row[schema['split_column']].strip().lower()
            if part not in result:
                raise ValueError('Split values must be train, val, test.')
            result[part].append(i)
    else:
        labels = [r[schema['target']] for r in rows]
        if any(missing(v) for v in labels):
            raise ValueError('Missing label in supervised dataset.')
        groups = [np.arange(len(rows))] if schema['task'] == 'regression' else [np.array([i for i, v in enumerate(labels) if v == c]) for c in sorted(set(labels))]
        for group in groups:
            if len(group) < 7:
                raise ValueError('Too few rows per class for three splits (minimum 7).')
            idx = rng.permutation(group)
            ntrain, nval = int(.70 * len(idx)), max(1, int(.15 * len(idx)))
            for part, ids in zip(result, (idx[:ntrain], idx[ntrain:ntrain+nval], idx[ntrain+nval:])):
                result[part].extend(ids.tolist())
    if any(not ids for ids in result.values()):
        raise ValueError('Each split must contain rows.')
    return {k: rng.permutation(v).tolist() for k, v in result.items()}


def write_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, allow_nan=False)
