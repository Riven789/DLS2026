import tempfile
import unittest
from pathlib import Path
import numpy as np
from data import Preprocessor, split_rows, fit_target, encode_target, boolean
from mlp import MLP, Optimizer, softmax, loss_and_gradient
from train import fit
from xor_demo import run

class TestMLP(unittest.TestCase):
    def test_gradients_by_finite_differences(self):
        rng = np.random.default_rng(19)
        x = rng.normal(size=(5, 2))
        for activation in ('relu', 'tanh'):
            for task in ('regression', 'binary', 'classification'):
                y = rng.normal(size=(5, 1)) if task == 'regression' else (np.array([[0.],[1.],[0.],[1.],[1.]]) if task == 'binary' else np.array([0,1,2,1,0]))
                net = MLP([2,3,3 if task == 'classification' else 1], activation, seed=17)
                _, grads = net.loss_grad(x, y, task)
                for key, value in net.params.items():
                    numerical = np.zeros_like(value)
                    for idx in np.ndindex(value.shape):
                        original = value[idx]
                        value[idx] = original + 1e-6
                        plus = net.loss(x, y, task)
                        value[idx] = original - 1e-6
                        minus = net.loss(x, y, task)
                        value[idx] = original
                        numerical[idx] = (plus-minus)/2e-6
                    np.testing.assert_allclose(grads[key], numerical, atol=2e-7, rtol=2e-5)

    def test_stable_logits(self):
        z = np.array([[1000.,-1000.],[-1000.,1000.]])
        np.testing.assert_allclose(softmax(z).sum(1), 1)
        for task, logits, y in [('classification',z,np.array([1,0])), ('binary',z[:, :1],np.array([[0.],[1.]]))]:
            loss, grad = loss_and_gradient(logits,y,task)
            self.assertTrue(np.isfinite(loss) and np.isfinite(grad).all())

    def test_numeric_sgd_update(self):
        params = {'W0':np.array([[.5],[-.25]]), 'b0':np.array([[.1]])}
        opt = Optimizer(params, 'sgd', lr=.1, weight_decay=0, momentum=0)
        opt.step(params, {'W0':np.array([[.05],[-.1]]), 'b0':np.array([[.05]])})
        np.testing.assert_allclose(params['W0'], [[.495],[-.24]])
        np.testing.assert_allclose(params['b0'], [[.095]])

    def test_adamw_decay_excludes_bias(self):
        p = {'W0':np.ones((1,1)), 'b0':np.ones((1,1))}
        Optimizer(p, lr=.1, weight_decay=.2).step(p, {k:np.zeros_like(v) for k,v in p.items()})
        self.assertAlmostEqual(p['W0'].item(), .98)
        self.assertEqual(p['b0'].item(), 1)

    def test_train_only_preprocessing_and_unknowns(self):
        features = dict(x='numeric', active='boolean', kind='categorical')
        rows = [dict(x='0', active='true', kind='A'),dict(x='2', active='false', kind='B')]
        pre = Preprocessor().fit(rows, features)
        transformed = pre.transform([dict(x='100', active='', kind='NEW')])
        self.assertEqual(pre.state['x']['mean'], 1)
        self.assertEqual(transformed[0,0], 99)
        self.assertEqual(transformed[0,3], 1)
        self.assertEqual(transformed[0,5], 1)
        self.assertTrue(np.isfinite(pre.transform([dict(x='',active='false',kind='')])).all())
        with self.assertRaises(ValueError): boolean('maybe')

    def test_split_disjoint_and_reproducible(self):
        rows = [dict(y=str(i%3)) for i in range(99)]
        schema = dict(target='y', task='classification')
        a = split_rows(rows, schema, seed=4)
        self.assertEqual(a,split_rows(rows,schema,seed=4))
        self.assertEqual(sorted(sum(a.values(),[])),list(range(99)))
        for p in a:
            self.assertEqual({rows[i]['y'] for i in a[p]}, {'0','1','2'})

    def test_labels_reject_missing_and_unseen(self):
        schema = dict(target='y', task='classification')
        state = fit_target([dict(y='a'),dict(y='b')],schema)
        for v in ('', 'c'):
            with self.assertRaises(ValueError): encode_target([dict(y=v)],schema,state)

    def test_checkpoint_roundtrip(self):
        net = MLP([3,4,2]); x = np.ones((3,3))
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'weights.npz'
            net.save(path)
            restored = MLP([3,4,2],seed=999).load(path)
            np.testing.assert_array_equal(net.forward(x), restored.forward(x))

    def test_xor_learning(self):
        _,y,p,_ = run(1800)
        np.testing.assert_array_equal(p >= .5, y.astype(bool))
        self.assertLess(np.max(abs(p-y)), .03)

    def test_regression_and_classification_learning(self):
        rng = np.random.default_rng(7)
        x = rng.normal(size=(240,2))
        for task in ('regression','classification'):
            y = (2*x[:,0]-.8*x[:,1]).reshape(-1,1) if task == 'regression' else np.argmax(np.column_stack([x[:,0],x[:,1],-x[:,0]-x[:,1]]),axis=1)
            net = MLP([2,16,3 if task == 'classification' else 1], seed=7)
            initial = net.loss(x[180:],y[180:],task)
            fit(net,x[:180],y[:180],x[180:],y[180:],task,epochs=100,lr=.01,patience=20)
            self.assertLess(net.loss(x[180:],y[180:],task),initial*.3)

if __name__ == '__main__': unittest.main()
