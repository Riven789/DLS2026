"""Predict from a new CSV. Targets are unnecessary; training transforms are reused."""
import argparse
import csv
import numpy as np
from data import read_csv
from evaluate import load_run
from mlp import sigmoid, softmax


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', required=True)
    p.add_argument('--run', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    model, meta, pre = load_run(args.run)
    z = model.forward(pre.transform(read_csv(args.csv)))
    task = meta['schema']['task']
    if task == 'regression':
        values = z * meta['target']['scale'] + meta['target']['mean']
        header, output = ['prediction'], values.tolist()
    else:
        probs = np.column_stack([1-sigmoid(z).ravel(), sigmoid(z).ravel()]) if task == 'binary' else softmax(z)
        classes = meta['target']['classes']
        header = ['prediction'] + ['p_'+v for v in classes]
        output = [[classes[int(p.argmax())], *p.tolist()] for p in probs]
    with open(args.out, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(output)
    print(f'Wrote {len(output)} predictions to {args.out}')


if __name__ == '__main__':
    main()
