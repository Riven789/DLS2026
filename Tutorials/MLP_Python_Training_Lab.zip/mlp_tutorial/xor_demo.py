"""Four logical cases, learned with a hidden layer. This is a fitting demo,
not a held-out generalization experiment: all four cases are used to train.
"""
import numpy as np
from mlp import MLP, Optimizer, sigmoid


def run(epochs=2500):
    x = np.array([[0,0],[0,1],[1,0],[1,1]], float)
    y = np.array([[0],[1],[1],[0]], float)
    net = MLP([2,8,1], activation='tanh', seed=7)
    opt = Optimizer(net.params, lr=.02, weight_decay=0)
    for _ in range(epochs):
        loss, grads = net.loss_grad(x,y,'binary')
        opt.step(net.params,grads)
    return x, y, sigmoid(net.forward(x)), net


if __name__ == '__main__':
    x, y, prob, net = run()
    for a, target, p in zip(x,y,prob):
        print(f'{a.astype(int)} XOR={int(target[0])} probability={p[0]:.6f}')
    print('Binary cross entropy:',net.loss(x,y,'binary'))
