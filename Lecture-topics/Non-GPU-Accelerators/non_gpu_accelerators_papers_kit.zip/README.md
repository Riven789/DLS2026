# Reading list: Non-GPU AI Accelerators

Companion papers to the deck and its lecture notes, grouped by section.
`reading_list.csv` and `reading_list.bib` hold the same list as data; `fetch_papers.sh` downloads
every arXiv entry into one folder per section and zips the result (`bash fetch_papers.sh`).
Entries without an arXiv identifier are listed with a URL and must be fetched by hand.

## 1. Overview: a decade of alternatives (slides 1-3)

- **Reuther, Michaleas, Jones, Gadepally, Samsi and Kepner (MIT Lincoln Laboratory) (2022).** *AI and ML accelerator survey and trends (IEEE HPEC 2022).* https://arxiv.org/abs/2210.04055  
  Survey paper. The fourth annual scatter of peak operations per second against power for published accelerators, with release dates and the neuromorphic, photonic and memristive entries; the model for the landscape chart. Slides 2 and 3.
- **Reuther, Michaleas, Jones, Gadepally, Samsi and Kepner (MIT Lincoln Laboratory) (2021).** *AI accelerator survey and trends (IEEE HPEC 2021).* https://arxiv.org/abs/2109.08957  
  Survey paper. The previous year's edition, with the 2016 to 2021 wave of startups (Graphcore, Groq, SambaNova, Cerebras) on one chart; read it to see which entries disappeared by 2026. Slides 2 and 3.
- **Hennessy and Patterson (2019).** *A new golden age for computer architecture (Communications of the ACM 62(2), Turing lecture).* https://cacm.acm.org/?p=7368  
  Primary paper (lecture). The end of Dennard scaling and Moore's law as the case for domain-specific architectures, with the TPU as the worked example; the thesis behind every program on the who's-who table. Slides 1 and 3.
- **Sastry and Emani (Argonne) (2026).** *ALCF AI Testbed (ATPESC 2026 slides, August 4, 2026).* https://extremecomputingtraining.anl.gov/sites/atpesc/files/2026-08/AI%20Testbeds.pdf  
  Laboratory slides. The non-GPU machines one DOE facility still runs in 2026: 4 CS-3, SN40L nodes with 16 RDUs each, 2 Tenstorrent Galaxy nodes, a 72-chip GroqRack and a Bow Pod64. Slides 3 and 35.
- **Argonne Leadership Computing Facility (2026).** *ALCF AI Testbed (system page).* https://ai.alcf.anl.gov  
  Facility page. The testbed inventory: GroqRack (72 chips), Cerebras CS-2, SambaNova DataScale (64 RDUs), Graphcore Bow Pod64, Habana Gaudi; the systems behind the ALCF evaluations cited later. Slides 3 and 32.
- **Hot Chips (2026).** *Hot Chips 2026 conference program (August 23-25, 2026).* https://hc2026.hotchips.org/program/conference/  
  Conference program. Where the 2026 accelerators were presented, including the Samsung LPDDR5X-PIM talk; the dates behind the timeline. Slides 3 and 28.
- **ServeTheHome (2025).** *Hot Chips 2025 preliminary schedule released.* https://www.servethehome.com/hot-chips-2025-preliminary-schedule-released/  
  Press, secondary source. The 2025 machine-learning sessions: Google Ironwood, d-Matrix Corsair, AMD MI350 and NVIDIA GB10 on one day; who was presenting non-GPU silicon that year. Slides 3, 11 and 28.
- **The Register (2026).** *AI chip startups soak up $1.1B in VC funding this week (February 25, 2026).* https://www.theregister.com/2026/02/25/ai_chips_vc_funding_1point1billion/  
  Press, secondary source. MatX ($500M Series B), Axelera (over $250M) and SambaNova ($350M with an Intel collaboration) in one week; the 2026 funding status on the who's-who table. Slides 3 and 34.

## 2. Principles: the memory wall, dataflow and SRAM (slides 4-8)

- **Kung (1982).** *Why systolic architectures? (IEEE Computer 15(1)).* https://www.cs.virginia.edu/~smk9u/CS6501F19/kung_-_1982_-_why_systolic_architectures.pdf  
  Primary paper (course mirror). The origin of the systolic-array vocabulary: data pulsing through a grid of cells so each operand fetched is used many times; the idea behind the MXU. Slides 5 and 7.
- **Horowitz (2014).** *Computing's energy problem (and what we can do about it) (ISSCC 2014, paper 1.1).* https://www.Gwern.net/doc/cs/hardware/2014-horowitz-2.pdf  
  Primary paper (mirror). The 45 nm energy table: adds and multiplies in fractions of a pJ to a few pJ, cache reads of 10 to 100 pJ, a DRAM access of 1 to 2 nJ; the bar chart on the SRAM slide. Slides 4 and 8.
- **Dally (NVIDIA and Stanford) (2016).** *High-performance hardware for machine learning (UC Berkeley CS294 lecture, October 19, 2016).* https://berkeley-deep-learning.github.io/cs294-dl-f16/slides/DL_HW_Berkeley_0916.pdf  
  Lecture slides. A legible reproduction of the Horowitz table (32-bit FP multiply 3.7 pJ, 8 KB SRAM read 5 pJ, 32-bit DRAM read 640 pJ) and the argument for keeping data on chip. Slide 8.
- **Dally, Turakhia and Han (2020).** *Domain-specific hardware accelerators (Communications of the ACM 63(7)).* https://www.doc.ic.ac.uk/~wl/teachlocal/arch/papers/cacm20dsa.pdf  
  Primary paper (course mirror). The four sources of accelerator gain and the updated energy costs: an add instruction about 4,000 times the add, 8 KB SRAM 50 fJ/bit, 100 MB on chip 0.7 pJ/bit, DDR4 about 20 pJ/bit, SerDes about 10 pJ/bit. Slides 6, 8 and 30.
- **Gholami, Yao, Kim, Hooper, Mahoney and Keutzer (2024).** *AI and memory wall (IEEE Micro 2024).* https://arxiv.org/abs/2403.14123  
  Primary paper. Peak server FLOP/s grew 3.0 times every two years, DRAM bandwidth 1.6 and interconnect 1.4; the three exponentials on the memory-wall slide. Slide 4.
- **Valiant (1990).** *A bridging model for parallel computation (Communications of the ACM 33(8)).* https://www.osti.gov/biblio/6502724  
  Bibliographic record (paper paywalled). The bulk-synchronous parallel model of compute, communicate and synchronize supersteps, which Graphcore's IPU implements literally. Slides 5 and 18.
- **Chen, Emer and Sze (2016).** *Eyeriss: a spatial architecture for energy-efficient dataflow for convolutional neural networks (ISCA 2016).* https://sands.kaust.edu.sa/classes/CS290E/F19/papers/eyeriss.pdf  
  Primary paper (course mirror). Defines the weight-stationary, output-stationary, no-local-reuse and row-stationary dataflows, the vocabulary for where operands wait in each machine. Slides 5 and 7.
- **Sze, Chen, Yang and Emer (2017).** *Efficient processing of deep neural networks: a tutorial and survey (Proceedings of the IEEE).* https://arxiv.org/abs/1703.09039  
  Survey paper. Dataflows, memory hierarchy and reduced precision organized in one place, with the energy-per-access hierarchy from registers to DRAM; the best single introduction to this section. Slides 4, 5 and 8.
- **Prabhakar, Zhang, Koeplinger, Feldman, Zhao, Hadjis, Pedram, Kozyrakis and Olukotun (2017).** *Plasticine: a reconfigurable architecture for parallel patterns (ISCA 2017).* https://sands.kaust.edu.sa/classes/CS290E/F19/papers/plasticine.pdf  
  Primary paper (course mirror). The coarse-grained reconfigurable array of pattern compute and memory units, 113 mm2 at 28 nm, 49 W, up to 76.9 times an FPGA's perf/W; the academic ancestor of SambaNova's RDU. Slides 5 and 17.
- **Fowers, Ovtcharov, Papamichael, ... Chung and Burger (Microsoft) (2018).** *A configurable cloud-scale DNN processor for real-time AI (ISCA 2018).* https://www.microsoft.com/en-us/research/publication/a-configurable-cloud-scale-dnn-processor-for-real-time-ai/  
  Primary paper (publication page). Project Brainwave: an FPGA soft NPU with weights pinned in on-chip memory, 10 to over 35 TFLOP/s at batch 1 on Stratix 10; the first data-center SRAM-resident serving design and Microsoft's step before Maia. Slides 8 and 22.
- **Shilov (Tom's Hardware) (2022).** *TSMC's 3nm node: no SRAM scaling implies more expensive CPUs and GPUs (December 16, 2022).* https://tomshardware.com/news/no-sram-scaling-implies-on-more-expensive-cpus-and-gpus  
  Press, secondary source. The SRAM bitcell stays at about 0.021 um2 from N5 to N3E, so on-chip capacity no longer gets cheaper with each node; why SRAM-only designs hit a capacity wall. Slide 8.
- **Somala (Epoch AI) (2026).** *Memory has grown to nearly two-thirds of AI chip component costs (May 21, 2026).* https://epoch.ai/data-insights/ai-chip-component-cost-shares  
  Analyst estimate, secondary source. HBM rose from 52 to 63 percent of accelerator component spending between Q1 2024 and Q4 2025, logic dies about 13 percent; the cost side of the SRAM-versus-HBM trade. Slides 4 and 8.

## 3. The Google TPU (slides 9-12)

- **Jouppi, Young, Patil, Patterson et al. (Google) (2017).** *In-datacenter performance analysis of a tensor processing unit (ISCA 2017).* https://arxiv.org/abs/1704.04760  
  Primary paper. TPU v1: a 256x256 8-bit MXU (65,536 MACs), 92 TOPS at 700 MHz, 24 MiB unified buffer, 8 GiB DDR3 at 34 GB/s, 75 W, 28 nm; 15 to 30 times a K80 and 30 to 80 times its perf/W, with the roofline showing DDR3 as the limit. Slides 6, 7 and 9.
- **Norrie, Patil, Yoon, Kurian, Li, Laudon, Young, Jouppi and Patterson (Google) (2020).** *Google's training chips revealed: TPUv2 and TPUv3 (Hot Chips 32 slides).* https://www.hc32.hotchips.org/assets/program/conference/day2/HotChips2020_ML_Training_Google_Norrie_Patil.v01.pdf  
  Primary conference slides (the talk behind Norrie et al., IEEE Micro 41(2), 2021). Why 128x128: about 1.6 times the utilization of one 256x256 array at constant FLOP/s; 256-chip 11.5 PF and 1,024-chip 100+ PF pods, 4 ICI links of 500 Gb/s in a 2D torus. Slides 7 and 9.
- **Norrie, Patil, Yoon, Kurian, Li, Laudon, Young, Jouppi and Patterson (Google) (2021).** *The design process for Google's training chips: TPUv2 and TPUv3 (IEEE Micro 41(2)).* https://www.Gwern.net/doc/ai/scaling/hardware/2021-norrie.pdf  
  Primary paper (mirror). TPU v2 as a different machine from v1: two TensorCores with VLIW scalar units driving vector units and 128 x 128 MXUs (32,768 operations per cycle at 700 MHz), BF16, HBM at 700 GB/s (20 times v1's DDR3), and the ICI torus. Slides 7 and 9.
- **Jouppi, Yoon, Ashcraft, Gottscho et al. (Google) (2021).** *Ten lessons from three generations shaped Google's TPUv4i (ISCA 2021, industry track).* https://www.cs.cmu.edu/~18742/papers/Jouppi2021.pdf  
  Primary paper (course mirror). TPUv4i: 7 nm, 138 TFLOP/s BF16, 128 MB of CMEM chosen as the knee of the curve, 175 W chip TDP; and the ten design lessons, including why TPU v2 went to two cores. Slides 7 and 10.
- **Jouppi, Kurian, Li, Ma, Nagarajan, Nai, Patil, Subramanian, Swing, Towles, Young, Zhou, Zhou and Patterson (Google) (2023).** *TPU v4: an optically reconfigurable supercomputer for machine learning with hardware support for embeddings (ISCA 2023).* https://arxiv.org/abs/2304.01433  
  Primary paper. 4,096 chips in 64 cubes joined by optical circuit switches (under 5 percent of cost and under 3 percent of power), SparseCores at 5 to 7 times on embeddings, 1.2 to 1.7 times an A100. Slide 10.
- **Jouppi, Lakshmanamurthy, Young and Patterson (Google) (2026).** *Google's training supercomputers from TPU v2 to Ironwood: architectural stability, scale, resilience, power efficiency, and sustainability across five generations (IEEE Micro).* https://arxiv.org/abs/2606.15870  
  Primary paper. Peak per chip up about 100 times (46 TFLOP/s BF16 to 4,614 FP8), HBM about 10 times, pods from 256 to 9,216 chips, peak perf per TDP watt about 30 times (Ironwood 6 times v5p), 93 percent goodput training Gemini 2.5. Slides 9 to 11.
- **Jouppi and Lakshmanamurthy (Google) (2025).** *Ironwood: delivering best in class perf, perf/TCO and perf/Watt for reasoning model training and serving (Hot Chips 2025 slides).* https://hc2025.hotchips.org/assets/program/conference/day2/61_Google_Ironwood-Final.pdf  
  Primary conference slides. The two-die TPU: 4,614 TFLOP/s FP8, 192 GiB HBM3E in 8 stacks at 7.3 TB/s, 1.2 TB/s ICI, 9,216 chips through OCS at 42.5 EFLOP/s FP8 with 1.77 PB of shared HBM. Slide 11.
- **Google Cloud (2026).** *TPU7x (Ironwood) system architecture (documentation).* https://docs.cloud.google.com/tpu/docs/tpu7x  
  Vendor documentation. The official per-chip row: 2,307 TFLOP/s BF16, 4,614 FP8, 192 GiB at 7,380 GB/s, 1,200 GB/s bidirectional ICI, 4x4x4 cubes up to 9,216 chips. Slides 11 and 31.
- **Google Cloud (2025).** *TPU v6e (Trillium) documentation.* https://docs.cloud.google.com/tpu/docs/v6e  
  Vendor documentation. 918 TFLOP/s BF16, 1,836 TOPS INT8, 32 GB at 1,638 GB/s, 800 GB/s ICI, 256-chip 2D torus. Slide 11.
- **Google Cloud (2025).** *TPU v5p documentation.* https://docs.cloud.google.com/tpu/docs/v5p  
  Vendor documentation. 459 TFLOP/s BF16, 95 GiB usable of 96 GiB HBM at 2,765 GB/s, 1,200 GB/s ICI, 8,960-chip 3D torus. Slide 11.
- **Google Cloud (2025).** *TPU v5e documentation.* https://docs.cloud.google.com/tpu/docs/v5e  
  Vendor documentation. 197 TFLOP/s BF16, 393 TOPS INT8, 16 GB at 800 GiB/s, 400 GB/s ICI, 256-chip 2D torus; the first inference-line TPU. Slide 11.
- **Lohmeyer (Google Cloud) (2024).** *Announcing the general availability of Trillium, our sixth-generation TPU (December 11, 2024).* https://cloud.google.com/blog/products/compute/trillium-tpu-is-ga  
  Vendor blog. 4.7 times peak per chip, double the HBM and ICI, 67 percent better energy efficiency; Gemini 2.0 trained on it; GA date on the business timeline. Slides 11 and 12.
- **Pichika and Singh (Google Cloud) (2024).** *Trillium MLPerf 4.1 training benchmarks (November 14, 2024).* https://cloud.google.com/blog/products/compute/trillium-mlperf-41-training-benchmarks  
  Vendor blog. GPT-3 175B in MLPerf Training 4.1 (preview): 99 percent scaling efficiency across Trillium pods with Multislice and up to 1.8 times the perf per dollar of v5p. Slides 11, 12 and 32.
- **Google Cloud (2025).** *Announcing Ironwood TPUs general availability and new Axion VMs (November 6, 2025).* https://cloud.google.com/blog/products/compute/ironwood-tpus-and-new-axion-based-vms-for-your-ai-workloads/  
  Vendor blog. Ironwood GA in the coming weeks, 10 times v5p peak, 9,216-chip superpods, and Anthropic's plan to access up to one million TPUs. Slides 11 and 12.
- **StorageReview (2026).** *Google announces TPU 8t Sunfish and TPU 8i Zebrafish (May 1, 2026).* https://www.storagereview.com/news/google-announces-tpu-8t-sunfish-and-tpu-8i-zebrafish  
  Press, secondary source. The TPU 8 columns: 8t at 12.6 PF FP4, 216 GB at 6.5 TB/s, 9,600-chip superpods; 8i at 10.1 PF FP4, 288 GB at 8.6 TB/s, 384 MB SRAM, the Boardfly network. Slides 11 and 31.

## 4. Cerebras and the wafer (slides 13-15)

- **Lie (Cerebras) (2023).** *Cerebras architecture deep dive: first look inside the hardware/software co-design for deep learning (IEEE Micro 43(3); author's blog version).* https://www.cerebras.ai/blog/cerebras-architecture-deep-dive-first-look-inside-the-hw-sw-co-design-for-deep-learning  
  Primary paper (author's web version, with a link to the IEEE Micro issue). The core: 48 KB of SRAM in eight banks, a four-FMAC FP16 datapath, dataflow triggering; weight streaming. The WSE-2's 7.5 PF FP16 used on slides 2, 13 and 31 is the figure analysts quote; the fact-check found no dense/sparse qualifier at its source. Slides 13 and 14.
- **Rocki, Van Essendelft, Sharapov, Schreiber, Morrison, Kibardin, Portnoy, Dietiker, Syamlal and James (2020).** *Fast stencil-code computation on a wafer-scale processor (SC20).* https://arxiv.org/abs/2010.03660  
  Primary paper. A bandwidth-bound 3D stencil from NETL runs near peak on a CS-1; the evidence that the wafer behaves as one device with PB/s of local bandwidth, and the reason labs bought the first units. Slides 13 and 14.
- **Cerebras Systems (2024).** *Cerebras Systems unveils world's fastest AI chip with 4 trillion transistors (WSE-3 press release, March 13, 2024).* https://www.cerebras.ai/press-release/cerebras-announces-third-generation-wafer-scale-engine  
  Vendor press release. WSE-3: 4 trillion transistors, 900,000 cores, 44 GB SRAM, TSMC 5 nm, '125 petaflops' with no precision or sparsity stated, 1.5 TB to 1.2 PB external memory, 2,048-system clusters, 24-trillion-parameter models. Slides 13 and 14.
- **Morgan (The Next Platform) (2024).** *Cerebras goes hyperscale with third-gen waferscale supercomputers (March 14, 2024).* https://www.nextplatform.com/ai/2024/03/14/cerebras-goes-hyperscale-with-third-gen-waferscale-supercomputers/1642584  
  Press, secondary source. The 8-wide FP16 SIMD of WSE-3 (4-wide before), the sparse qualifier on the 256-exaflop cluster figure, MemoryX tiers from 24 TB to 1,200 TB, and CG-1 at $100M for 32 nodes. Slides 13 and 14.
- **Cerebras Systems (2024).** *Cerebras and G42 announce Condor Galaxy 3 (March 13, 2024).* https://cerebras.ai/press-release/cerebras-g42-announce-condor-galaxy-3  
  Vendor press release. CG-3 in Dallas with 64 CS-3 at 8 'AI exaflops'; with CG-1 and CG-2 the network totals 16; the Condor Galaxy table. Slide 14.
- **Cerebras Systems (SEC Form S-1) (2024).** *Form S-1 registration statement (filed September 30, 2024).* https://www.sec.gov/Archives/edgar/data/2021728/000162828024041596/cerebras-sx1.htm  
  Filing (SEC). Revenue of $24.6M (2022), $78.7M (2023) and $136.4M (H1 2024); G42 was 83 percent of 2023 revenue and 87 percent of H1 2024 revenue. Slides 14 and 15.
- **Cerebras Systems (2024).** *Introducing Cerebras Inference: AI at instant speed (August 27, 2024).* https://cerebras.ai/blog/introducing-cerebras-inference-ai-at-instant-speed  
  Vendor blog. The launch: Llama 3.1 8B at 1,800 tokens/s and 70B at 450 tokens/s with 16-bit weights, claimed 20 times GPU clouds; the first bar of the speed chart. Slides 15 and 33.
- **Cerebras Systems (2024).** *Cerebras triples its industry-leading inference performance (October 25, 2024).* https://www.cerebras.ai/press-release/cerebras-triples-its-industry-leading-inference-performance-setting-new-all-time-record  
  Vendor press release. 2,100 tokens/s on the 70B Llama model as measured by Artificial Analysis; the second bar of the speed chart. Slides 15 and 33.
- **Futurum Group (2026).** *Cerebras S-1 teardown: is the $23B wafer-scale IPO the end of GPU homogeneity? (April 22, 2026).* https://futurumgroup.com/insights/cerebras-s-1-teardown-is-the-23b-wafer-scale-ipo-the-end-of-gpu-homogeneity/  
  Analyst note, secondary source. The April 2026 S-1: 2025 revenue $510M, MBZUAI 62 and G42 24 percent (86 together), backlog $24.6B, GAAP profit only from a $363.3M one-time gain, OpenAI terms of 750 MW with an option to 2 GW. Slides 14 and 15.
- **TechCrunch (2026).** *Cerebras raises $5.5B, kicking off 2026's IPO season with a bang (May 14, 2026).* https://techcrunch.com/2026/05/14/cerebras-raises-5-5b-kicking-off-2026s-ipo-season-with-a-bang  
  Press, secondary source. Priced at $185 (range raised twice), $5.5B raised on 30 million shares, opened at $385 and closed at $311, about $66B at the close per Yahoo Finance. Slides 15 and 34.
- **Cerebras Systems (SEC Form 8-K) (2026).** *Cerebras announces second quarter 2026 financial results (August 12, 2026).* https://www.sec.gov/Archives/edgar/data/0002021728/000162828026056186/cbrsannouncesfinancialresu.htm  
  Filing (SEC). Q2 2026 GAAP revenue $180.1M, RPO $25.4B, $8.6B cash, full-year core revenue guide of $880M to $890M. Slides 15 and 34.
- **Cerebras Systems (2026).** *Cerebras unveils CS-4: up to 30 times faster than GPU-based solutions (August 18, 2026).* https://investors.cerebras.ai/node/7401/pdf  
  Vendor press release. Three WSE-3T wafers per Nexus rack, 250 'PFLOPS' and 43.2 PB/s per wafer (750 per rack), 53.5 PB/s fabric, 2 us wafer-to-wafer; over 4,400 tokens/s per user on gpt-oss-120B. Slides 15 and 33.
- **Morgan (The Next Platform) (2026).** *Cerebras overclocks WSE-3 waferscale engine to boost inference oomph in Nexus CS-4 (August 19, 2026).* https://www.nextplatform.com/compute/2026/08/19/cerebras-overclocks-wse-3-waferscale-engine-to-boost-inference-oomph-in-nexus-cs-4/5289400  
  Press, secondary source. WSE-3T is the same 900,000-core die at about twice the power (clock estimated at 1.4 to 2.8 GHz, the author's estimate), three backpacks per rack, GA later in Q3 2026. Slide 15.

## 5. Dataflow and streaming machines (slides 16-20)

- **Abts, Ross, Sparling et al. (Groq) (2020).** *Think fast: a tensor streaming processor (TSP) for accelerating deep learning workloads (ISCA 2020).* https://groq.com/wp-content/uploads/2024/02/2020-Isca.pdf  
  Primary paper. One core of functional slices on a 25 x 29 mm 14 nm die, 26.8 billion transistors, 220 MiB of SRAM at about 55 TiB/s, 820 TOPS at 1 GHz (900 MHz nominal), no caches or arbiters; ResNet-50 at 20.4K images/s at batch 1. Slides 5, 6 and 16.
- **Abts, Kimmell, Ling, Kim et al. (Groq) (2022).** *A software-defined tensor streaming multiprocessor for large-scale machine learning (ISCA 2022).* https://groq.com/wp-content/uploads/2024/02/GroqISCAPaper2022_ASoftwareDefinedTensorStreamingMultiprocessorForLargeScaleMachineLearning.pdf  
  Primary paper. Determinism extended to the network: 8-TSP nodes, 72-TSP racks, a Dragonfly to 10,440 TSPs, 722 ns per hop, forward error correction and software replay instead of link retry. Slides 16 and 31.
- **Groq (2024).** *Groq LPU inference engine leads in first independent LLM benchmark (February 13, 2024).* https://groq.com/newsroom/groq-lpu-inference-engine-leads-in-first-independent-llm-benchmark  
  Vendor press release. Llama 2 Chat 70B at 241 tokens/s on Artificial Analysis, the first independent LLM API measurement of a non-GPU chip. Slides 16 and 33.
- **DatacenterDynamics (2025).** *Nvidia to license tech from AI inference chip company Groq, hire its leadership (December 2025).* https://www.datacenterdynamics.com/en/news/nvidia-to-license-tech-from-ai-inference-chip-company-groq-hire-its-leadership/  
  Press, secondary source. A non-exclusive license plus the hiring of Jonathan Ross and Sunny Madra; the $20B figure reported by CNBC and not confirmed; Groq stays independent with GroqCloud. Slides 16, 34 and 35.
- **Mann (The Register) (2026).** *Nvidia slaps $20B Groq tech into massive new LPX racks to speed AI response time (March 16, 2026).* https://www.theregister.com/2026/03/16/nvidia_lpx_groq_3/  
  Press, secondary source. The GTC 2026 LPX rack: 256 LPUs, about 500 MB of SRAM and 150 TB/s per LPU, 1.2 PF FP8 each, shipping later in 2026; in NVIDIA's split the LPX runs the FFN and MoE half of decode and speculative drafts, while Vera Rubin does prefill, attention and the KV cache. Slides 16 and 31.
- **Tom's Hardware (2026).** *Nvidia presents Groq 3 LPX architecture and unveils its first third-party inference benchmark (August 26, 2026).* https://tomshardware.com/tech-industry/semiconductors/nvidia-presents-groq-3-lpx-architecture-and-unveils-its-first-third-party-inference-benchmark  
  Press, secondary source. Hot Chips 2026: LP30 with no HBM, 350 ns chip to chip; 256 chips give 128 GB, 40 PB/s and 315 PF FP8; Gemma 4 31B at 3,431 tokens/s on a private endpoint at concurrency 1; in production. Slides 16 and 33.
- **Prabhakar, Sivaramakrishnan, Gandhi, Du, ... Olukotun (SambaNova) (2024).** *SambaNova SN40L: scaling the AI memory wall with dataflow and composition of experts (MICRO 2024).* https://arxiv.org/abs/2405.07518  
  Primary paper. The three-tier SRAM, HBM and DDR design; Samba-CoE with 150 experts and about a trillion parameters on one 8-socket node, 15 to 31 times faster model switching, 3.7 times a DGX H100. Slides 8 and 17.
- **Prabhakar (SambaNova) (2024).** *SambaNova SN40L RDU: breaking the barrier of trillion+ parameter scale gen AI computing (Hot Chips 2024 slides).* https://www.hc2024.hotchips.org/assets/program/conference/day1/48_HC2024.Sambanova.Prabhakar.final-withoutvideo.pdf  
  Primary conference slides. TSMC 5 nm, 102 billion transistors, 1,040 PCUs and PMUs, 520 MB SRAM, 64 GB HBM at 1.6 TB/s, 1.5 TB DDR, 638 TFLOP/s BF16; 16 chips serve Llama 3.1 405B at 114 tokens/s. Slides 17 and 31.
- **SambaNova Systems (2026).** *SambaNova unveils fastest chip for agentic AI, collaborates with Intel, and raises $350M+ (February 24, 2026).* https://www.businesswire.com/news/home/20260224971025/en/  
  Vendor press release. SN50: five times the SN40L's compute and four times its network, 256-chip domains, Llama 3.3 70B FP8 at 895 tokens/s per user against 184 on a B200 (vendor test); Series E and the Intel collaboration. Slides 17 and 34.
- **Jia, Tillman, Maggioni and Scarpazza (Citadel) (2019).** *Dissecting the Graphcore IPU architecture via microbenchmarking.* https://arxiv.org/abs/1912.03413  
  Independent measurement paper. GC2: 1,216 tiles, 304 MiB of SRAM, 30.7 TB/s measured against 45 nominal, 133 ns exchange latency, 64 GB/s IPU-Links; the only outside look at the IPU. Slides 18 and 31.
- **Ward-Foxton (EE Times Asia) (2022).** *Graphcore supercharges IPU with wafer-on-wafer (March 9, 2022).* https://www.eetasia.com/?p=36263  
  Press, secondary source. Bow: a power-delivery wafer with deep-trench capacitors hybrid-bonded under the unchanged 7 nm IPU, 1.325 to 1.85 GHz, 350 TFLOP/s; Bow Pod systems from Pod16 to Pod1024; the planned 10-exaflop Good computer. (The $149,995 list price on slide 18 was the GC200 IPU-POD16 of June 2021, before Bow.) Slide 18.
- **Robinson (The Register) (2023).** *AI chip biz Graphcore seeks capital to remain going concern (October 6, 2023).* https://www.theregister.com/2023/10/06/brit_ai_chip_outfit_graphcore/  
  Press, secondary source. The 2022 accounts: revenue $2.7M (down 46 percent), pre-tax loss $204.6M, staff from 631 to 494, a material going-concern uncertainty; the year before the SoftBank sale. Slides 18 and 35.
- **The Register (2024).** *Tenstorrent's Blackhole chips boast 768 RISC-V cores and almost as many FLOPS (August 27, 2024).* https://www.theregister.com/2024/08/27/tenstorrent_ai_blackhole/  
  Press, secondary source. The Hot Chips 36 Blackhole talk: 140 Tensix, 16 big and 752 baby RISC-V cores, 745 TFLOP/s FP8 and 372 FP16, 10 x 400 GbE, 32-chip Galaxy at 23.8 PF FP8 with 1 TB. Slides 19 and 31.
- **ServeTheHome (2025).** *Rebellions REBEL-Quad UCIe and 144GB HBM3E accelerator at Hot Chips 2025 (August 24, 2025).* https://www.servethehome.com/rebellions-rebel-quad-ucie-and-144gb-hbm3e-accelerator-at-hot-chips-2025/  
  Press, secondary source. Four Samsung SF4X chiplets on CoWoS-S joined by UCIe-A, four HBM3E sites (144 GB), Llama 3.3 70B at 35.5 ms per token on a development board. Slide 20.
- **Lam (Chips and Cheese) (2024).** *FuriosaAI's RNGD at Hot Chips 2024: accelerating AI with a more flexible primitive (September 11, 2024).* https://chipsandcheese.com/p/furiosaais-rngd-at-hot-chips-2024-accelerating-ai-with-a-more-flexible-primitive  
  Independent analysis, secondary source. The written record of the RNGD talk: TSMC 5 nm, 1 GHz, 150 W, 48 GB HBM3 at 1.5 TB/s, 64 slices plus a spare per unit, 256 MB SRAM; the tensor-contraction primitive of Furiosa's ISCA 2024 paper. Slide 20.

## 6. The hyperscalers' chips and the established vendors (slides 21-24)

- **AWS Machine Learning Blog (2023).** *AWS Inferentia2 builds on AWS Inferentia1 by delivering 4x higher throughput and 10x lower latency (June 13, 2023).* https://aws.amazon.com/blogs/machine-learning/aws-inferentia2-builds-on-aws-inferentia1-by-delivering-4x-higher-throughput-and-10x-lower-latency/  
  Vendor blog. The Inferentia1 and 2 table: 128 against 380 TOPS INT8, 64 against 190 TFLOP/s BF16, 8 GB of DRAM at 50 GB/s against 32 GB of HBM at 820 GB/s, NeuronCore-v1 to v2. Slide 21.
- **Barr (AWS) (2024).** *Amazon EC2 Trn2 instances and Trn2 UltraServers for AI/ML training and inference are now available (December 3, 2024).* https://aws.amazon.com/blogs/aws/amazon-ec2-trn2-instances-and-trn2-ultraservers-for-aiml-training-and-inference-is-now-available  
  Vendor blog. Trainium2: 8 NeuronCores, 96 GiB HBM at 2.9 TB/s, 1.3 PF FP8 dense (5.2 sparse); 16-chip instances on a 1 TB/s 2D torus; 64-chip UltraServers at 83 PF dense; 30 to 40 percent better price-performance than P5e (AWS claim). Slides 21 and 31.
- **AWS (2025).** *Amazon EC2 Trn3 UltraServers (product page).* https://aws.amazon.com/ec2/instance-types/trn3/  
  Vendor page. Trainium3: AWS's first 3 nm chip, 144 GB HBM3e at 4.9 TB/s, 144-chip UltraServers at 362 PF MXFP8 with 20.7 TB and 706 TB/s, NeuronSwitch-v1 and NeuronLink-v4 (2.56 TB/s per chip in the Neuron documentation, the 2.6 TB/s on slide 21); 4.4 times Trn2 (AWS claim). Slide 21.
- **TechCrunch (2025).** *Amazon releases an impressive new AI chip and teases an Nvidia-friendly roadmap (December 2, 2025).* https://techcrunch.com/2025/12/02/amazon-releases-an-impressive-new-ai-chip-and-teases-a-nvidia-friendly-roadmap  
  Press, secondary source. Trainium3 at re:Invent 2025 and the Trainium4 preview with NVIDIA NVLink Fusion support, no date given. Slide 21.
- **ServeTheHome (2024).** *Microsoft Maia 100 AI accelerator for Azure (Hot Chips 2024).* https://servethehome.com/microsoft-maia-100-ai-accelerator-for-azure  
  Press, secondary source. The Hot Chips 2024 talk: TSMC N5 on CoWoS-S, 64 GB HBM2E, about 500 MB of on-chip SRAM, 16 clusters of 4 tiles, 12 x 400 GbE, 700 W TDP (about 500 W in service), 6- and 9-bit formats. Slide 22.
- **Microsoft Azure Infrastructure Blog (2026).** *Deep dive into the Maia 200 architecture (January 2026).* https://techcommunity.microsoft.com/blog/azureinfrastructureblog/deep-dive-into-the-maia-200-architecture/4489312  
  Vendor blog. Maia 200: TSMC N3P, 216 GB HBM3e at 7 TB/s, 272 MB SRAM, 10.15 PF FP4 and 5.07 PF FP8, 750 W, a 2.8 TB/s Ethernet scale-up link and 6,144-chip domains; deployed only inside Azure, with no BF16 figure published. Slides 22 and 31.
- **Meta AI (2024).** *Our next-generation Meta Training and Inference Accelerator (April 10, 2024).* https://ai.meta.com/blog/next-generation-meta-training-inference-accelerator-AI-MTIA/  
  Vendor blog. The v1 against v2 table: 354 TOPS INT8 dense (708 sparse), 177 TFLOP/s BF16 dense, 256 MB SRAM at 2.7 TB/s, 128 GB LPDDR5 at 204.8 GB/s, 90 W, 1.35 GHz. Slides 22 and 31.
- **HPCwire (2026).** *Meta packs gobs of HBM into homegrown AI accelerators (March 11, 2026).* https://www.hpcwire.com/2026/03/11/meta-packs-gobs-of-hbm-into-homegrown-ai-accelerators/  
  Press, secondary source. The 2026 MTIA family: MTIA 400 at 1,200 W in 72-chip racks, MTIA 450 with 288 GB at 18.4 TB/s and 21 PF MX4, MTIA 500 with up to 512 GB, 27.6 TB/s, 30 PF MX4 and 1,700 W in 2027. Slide 22.
- **Tom's Hardware (2025).** *OpenAI, Broadcom to co-develop 10GW of custom AI chips (October 13, 2025).* https://www.tomshardware.com/openai-broadcom-to-co-develop-10gw-of-custom-ai-chips  
  Press, secondary source. The deal terms: 10 GW of accelerators and racks, OpenAI designing and Broadcom building and deploying over Ethernet, from H2 2026 to the end of 2029. Slides 23 and 34.
- **Kaplan (Intel) (2024).** *Intel Gaudi 3 AI accelerator: architected for gen AI training and inference (Hot Chips 2024 slides).* https://www.hc2024.hotchips.org/assets/program/conference/day1/60_HC2024.Intel.RomanKaplan.Gaudi3-0826.pdf  
  Primary conference slides. Two 5 nm dies, 8 MMEs and 64 TPCs, 96 MB SRAM at 12.8 TB/s, 128 GB HBM2e at 3.67 TB/s, 1,835 TFLOP/s for both BF16 and FP8 matrix, 900 W air or 1,200 W liquid, 24 x 200 GbE. Slide 24.
- **Qualcomm (2023).** *Qualcomm Cloud AI 100 Ultra product brief.* https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Prod-Brief-QCOM-Cloud-AI-100-Ultra.pdf  
  Vendor datasheet. 64 AI cores, 870 TOPS INT8, 576 MB SRAM, 128 GB LPDDR4x at 548 GB/s, 150 W on a PCIe card. Slide 24.
- **Kennedy (ServeTheHome) (2025).** *Qualcomm announces new integrated AI racks with 768GB cards and a 200MW AI deal (October 27, 2025).* https://www.servethehome.com/qualcomm-announces-new-integrated-ai-racks-with-768gb-cards-and-a-200mw-ai-deal/  
  Press, secondary source. AI200 with 768 GB of LPDDR per card, AI250 with near-memory compute and a claimed 10 times effective bandwidth, about 160 kW liquid-cooled racks, Humain's 200 MW from 2026. Slides 24, 28 and 34.
- **ServeTheHome (2024).** *IBM Telum II processor and Spyre AI updates at Hot Chips 2024 (August 26, 2024).* https://servethehome.com/ibm-telum-ii-processor-and-spyre-ai-updates-at-hot-chips-2024  
  Press, secondary source. Spyre: 32 cores with 2 MB scratchpads, Samsung 5 nm, 300 TOPS, 75 W, 128 GB LPDDR5 per card, eight cards per drawer as presented at Hot Chips (IBM's 2025 GA release gives up to 48 cards per z17 and 16 per Power11). Slide 24.
- **Talpes, Williams and Das Sarma (Tesla) (2022).** *The microarchitecture of Tesla's exa-scale computer (Hot Chips 34 slides).* https://hc34.hotchips.org/assets/program/conference/day2/Machine%20Learning/HotChips_tesla_dojo_uarch.pdf  
  Primary conference slides. D1: TSMC 7 nm, 645 mm2, 354 nodes at 2 GHz, 362 TFLOP/s BF16/CFP8, 440 MB SRAM, 2 TB/s per die edge; a 5 x 5 tile of known-good dies. Slide 24.
- **TechCrunch (2025).** *Tesla Dojo: the rise and fall of Elon Musk's AI supercomputer (September 2, 2025).* https://techcrunch.com/2025/09/02/tesla-dojo-the-rise-and-fall-of-elon-musks-ai-supercomputer/  
  Press, secondary source. Dojo shut down and its team disbanded in mid-August 2025, Dojo 2 called an evolutionary dead end, the $16.5B Samsung AI6 contract weeks earlier. Read with the January 2026 TechCrunch report of the Dojo3 restart. Slides 24 and 35.
- **TechCrunch (2026).** *Elon Musk says Tesla's restarted Dojo3 will be for space-based AI compute (January 20, 2026).* https://techcrunch.com/2026/01/20/elon-musk-says-teslas-restarted-dojo3-will-be-for-space-based-ai-compute  
  Press, secondary source. Five months after the team was disbanded, Musk says Dojo3 is restarted on AI5-family silicon, aimed at space-based AI compute rather than Tesla's video training; why slide 24 says Tesla paused rather than stopped. Slides 3 and 24.

## 7. China: Ascend, CloudMatrix and the policy backdrop (slides 25-27)

- **Liao, Tu, Xia and Zhou (Huawei) (2019).** *DaVinci: a scalable architecture for neural network computing (Hot Chips 31 slides).* https://www.old.hotchips.org/hc31/HC31_1.11_Huawei.Davinci.HengLiao_v4.0.pdf  
  Primary conference slides. The Da Vinci core's 16 x 16 x 16 cube (4,096 FP16 or 8,192 INT8 MACs per cycle) with vector and scalar units; Ascend 910 at 256 TFLOP/s FP16, 350 W, 7+ nm EUV. Slide 25.
- **Feldgoise and Dohmen (CSET) (2024).** *Pushing the limits: Huawei's AI chip tests U.S. export controls (June 17, 2024).* https://cset.georgetown.edu/publication/pushing-the-limits-huaweis-ai-chip-tests-u-s-export-controls/  
  Analyst note, secondary source. Ascend 910 against 910B: TSMC 7 nm against SMIC N+2, 30-32 against 20-25 active cores, 320 against 400 TFLOP/s FP16 (part of the gain a counting change), HBM2e at up to 1.6 TB/s and 64 GB; low SMIC yields inferred. Slides 25 and 27.
- **Patel, Nishball, Xie et al. (SemiAnalysis) (2025).** *Huawei AI CloudMatrix 384: China's answer to Nvidia GB200 NVL72 (April 16, 2025).* https://newsletter.semianalysis.com/p/huawei-ai-cloudmatrix-384-chinas-answer-to-nvidia-gb200-nvl72  
  Analyst note, secondary source. 384 Ascend 910C in 16 racks with 6,912 400G LPO transceivers, about 300 PF dense BF16, 3.6 times the HBM and 2.1 times the bandwidth of an NVL72 at about 3.9 times the power (about 559 kW against 145 kW, all-in; 2.3 times per FLOP, 1.8 per TB/s, 1.1 per TB); most 910B/C dies from TSMC via Sophgo, HBM mainly Samsung. Slides 25, 26 and 31.
- **Zuo, Lin, Deng et al. (Huawei Cloud) (2025).** *Serving large language models on Huawei CloudMatrix384.* https://arxiv.org/abs/2506.12708  
  Primary paper. The system as Huawei describes it: 384 Ascend NPUs and 192 Kunpeng CPUs on the Unified Bus; DeepSeek-R1 served at 6,688 prefill and 1,943 decode tokens/s per NPU. Slide 26.
- **Xu (Huawei Connect 2025 keynote) (2025).** *Groundbreaking SuperPoD interconnect: leading a new paradigm for AI infrastructure (September 18, 2025).* https://www.huawei.com/en/news/2025/9/hc-xu-keynote-speech  
  Vendor keynote text. The Ascend 950PR (Q1 2026), 950DT (Q4 2026, HiZQ 2.0 HBM, 144 GB at 4 TB/s), 960 (Q4 2027) and 970 (Q4 2028); Atlas 950 (8,192 chips, 8 EF FP8) and 960 (15,488 chips, 30 EF FP8) SuperPoDs; UnifiedBus; the mainland 'will lag behind in process nodes'. The 960 and 970 dates and figures were revised in September 2026 (see the Tom's Hardware entry). Slides 25 and 26.
- **Tom's Hardware (2026).** *Huawei details AI accelerator roadmap, pulls in next-generation Ascend NPUs by quarters; FP4 performance of the Ascend 960PR doubles expectations (Huawei Connect 2026).* https://www.tomshardware.com/tech-industry/artificial-intelligence/huawei-details-ai-accelerator-roadmap-pulls-in-next-generation-ascend-npus-by-quarters-fp4-performance-of-the-ascend-960pr-doubles-expectations  
  Press, secondary source. The September 18, 2026 revision: 960DT in Q1 2027 and 960PR in Q3 2027 (2 PF FP8, 8 PF FP4) with a 2.2 TB/s link; 970 in 2028 at 3.6 PF FP8, 14 PF FP4 and 4.4 TB/s; a 980 in 2029. Slide 25.
- **The Register (2025).** *DeepSeek's R2 training on Huawei Ascend reportedly failed (August 14, 2025).* https://www.theregister.com/2025/08/14/dodgy_huawei_deepseek/  
  Press, secondary source (relaying the Financial Times). DeepSeek never completed a successful R2 training run on Ascend, citing unstable chips, slow interconnect and immature software, and went back to H20s for training. Slide 25.
- **Recode China AI (2025).** *Who will fill Nvidia's AI chip void in China?.* https://recodechinaai.substack.com/p/who-will-fill-nvidias-ai-chip-void  
  Analyst newsletter, secondary source. Hanguang 800 (12 nm, 17 billion transistors, 820 TOPS), Kunlun 2 (7 nm, 128 TFLOP/s FP16, about 120 W), Cambricon MLU370 (96 TF) and MLU590 (345 TF, FP8). Slide 27.
- **Caixin Global (2025).** *Baidu unveils ambitious AI chip roadmap targeting 1 million-card cluster by 2030 (November 14, 2025).* https://www.caixinglobal.com/2025-11-14/baidu-unveils-ambitious-ai-chip-roadmap-targeting-1-million-card-cluster-by-2030-102382580.html  
  Press, secondary source. Kunlun M100 (2026, inference) and M300 (2027, training), the 30,000-card P800 cluster of April 2025, 512-card nodes in 2026, a million cards by 2030. Slide 27.
- **TrendForce (2025).** *Alibaba T-Head PPU lands China Unicom deal, reportedly matches Nvidia H20 performance (September 17, 2025).* https://www.trendforce.com/news/2025/09/17/news-alibaba-t-head-ppu-lands-china-unicom-deal-reportedly-matches-nvidia-h20-performance/  
  Analyst press, secondary source. The PPU: 96 GB HBM2e, 700 GB/s chip to chip, domestic 7 nm; a 16,384-card China Unicom order. Slide 27.
- **TrendForce (2026).** *China GPU race intensifies: Cambricon turns profitable in 2025, Moore Threads and MetaX narrow losses (March 9, 2026).* https://www.trendforce.com/news/2026/03/09/news-china-gpu-race-intensifies-cambricon-turns-profitable-in-2025-moore-threads-metax-narrow-losses/  
  Analyst press, secondary source. Cambricon's 2025 revenue of RMB 6.5B (up 453 percent) and net profit of RMB 2.06B after a 2024 loss; Moore Threads and MetaX revenue. Slide 27.
- **NVIDIA (SEC Form 8-K) (2025).** *Form 8-K: H20 export license requirement (April 9, 2025, signed April 15).* https://www.sec.gov/Archives/edgar/data/1045810/000104581025000082/nvda-20250409.htm  
  Filing (SEC). The license requirement for the H20 notified April 9, made indefinite April 14, with up to about $5.5B of charges; the April 2025 step on the policy timeline. Slide 27.
- **Morrison Foerster (2025).** *BIS issues interim final rule: framework for artificial intelligence diffusion (February 4, 2025).* https://www.mofo.com/resources/insights/250204-bis-issues-interim-final-rule  
  Law-firm summary, secondary source. The January 13, 2025 rule and its three country tiers (authorized, restricted including China, all others), with the May 2025 rescission noted. Slide 27.
- **Kirkland and Ellis (2025).** *BIS rescission of the Biden administration's AI diffusion rule (May 27, 2025).* https://www.kirkland.com/publications/kirkland-alert/2025/05/bis-rescission-of-the-biden-administration  
  Law-firm summary, secondary source. The May 13, 2025 rescission and the GP10 guidance naming Ascend 910B, 910C and 910D as presumptively made in violation of US controls. Slide 27.
- **Associated Press (via The Atlanta Journal-Constitution) (2025).** *Nvidia, AMD to pay 15% of China chip sale revenue to US government (August 2025).* https://www.ajc.com/news/2025/08/nvidia-amd-to-pay-15-of-china-chip-sale-revenue-to-us-government-2  
  Press, secondary source. H20 and MI308 sales resumed with 15 percent of China revenue to the US government as a license condition (FT, confirmed to AP by an official). Slide 27.
- **Bloomberg (2025).** *China agency orders firms to stop buying Nvidia AI chip, FT says (September 17, 2025).* https://www.bloomberg.com/news/articles/2025-09-17/china-agency-orders-firms-to-stop-buying-nvidia-ai-chip-ft-says  
  Press, secondary source. The Cyberspace Administration of China told Alibaba and ByteDance to stop testing and cancel orders for the RTX Pro 6000D; the last point on the policy timeline. Slide 27.

## 8. Emerging designs: in-memory, hardwired, photonic, neuromorphic (slides 28-30)

- **SiliconANGLE (2025).** *Chip startup d-Matrix raises $275M to speed up inference with memory-compute (November 12, 2025).* https://siliconangle.com/2025/11/12/chip-startup-d-matrix-raises-275m-speed-inference-memory-compute/  
  Press, secondary source. The $275M round at $2B; Corsair with 2 GB of SRAM per card, part of it repurposed as multipliers, 256 GB LPDDR5 behind, '9,600 TOPS' in MXINT4 (vendor); Raptor (2026) to stack DRAM on 4 nm (vendor plan). For the chiplet count (two chips of four 6 nm chiplets per card) use the ServeTheHome Hot Chips 2025 entry. Slides 3 and 28.
- **ServeTheHome (2025).** *d-Matrix presents Corsair, an in-memory computing architecture for inference, at Hot Chips 2025.* https://www.servethehome.com/d-matrix-presents-corsair-an-in-memory-computing-architecture-for-inference-at-hot-chips-2025/  
  Press, secondary source. The Hot Chips 2025 talk: a Corsair card is two chips of four chiplets each, eight TSMC 6 nm chiplets with 2 GB of SRAM in all, 256 GB of LPDDR5X, 275 to 550 W; the Pavehawk 3D-DRAM test vehicle. Slide 28.
- **Gomez-Luna, El Hajj, Fernandez, Giannoula, Oliveira and Mutlu (2021).** *Benchmarking a new paradigm: an experimental analysis of a real processing-in-memory architecture.* https://arxiv.org/abs/2105.03814  
  Primary paper. The first independent characterization of commercial processing-in-DRAM (UPMEM DIMMs with 128 DRAM processing units each): where moving compute to the memory pays and where it does not. Slide 28.
- **TechCrunch (2023).** *AI chip startup Mythic rises from the ashes with $13M, new CEO (March 9, 2023).* https://techcrunch.com/2023/03/09/ai-chip-startup-mythic-rises-from-the-ashes-with-13m-new-ceo  
  Press, secondary source. The analog flash-in-memory company nearly out of money in November 2022, revived with $13M and a defense focus (before the $125M round of December 2025, separate entry). Slides 28 and 35.
- **Mythic (BusinessWire) (2025).** *Mythic raises $125 million (December 17, 2025).* https://www.businesswire.com/news/home/20251217546249/en/  
  Vendor press release. An oversubscribed $125M round three years after the near-shutdown of November 2022; the analog in-memory company back in business for edge inference. Slides 28 and 35.
- **HPCwire (2025).** *Untether AI team acquired by AMD; product support discontinued (June 5, 2025).* https://www.hpcwire.com/off-the-wire/untether-ai-team-acquired-by-amd-product-support-discontinued/  
  Press release, secondary source. Untether ends supply and support of speedAI and its SDK as AMD takes the team. Slides 28, 29 and 35.
- **CNX Software (2026).** *Taalas HC1 hardwired Llama 3.1 8B AI accelerator delivers up to 17,000 tokens/s (February 22, 2026).* https://www.cnx-software.com/2026/02/22/taalas-hc1-hardwired-llama-3-1-8b-ai-accelerator-delivers-up-to-17000-tokens-s/  
  Press, secondary source. HC1: Llama 3.1 8B in the metal layers, TSMC 6 nm, 815 mm2, 53 billion transistors, mixed 3- and 6-bit parameters, close to 17,000 tokens/s for one user. Slide 29.
- **NYU Shanghai RITS (2026).** *AMD acquires Taalas, the startup etching LLMs into silicon (August 2026).* https://rits.shanghai.nyu.edu/ai/amd-acquires-taalas-the-startup-etching-llms-into-silicon/  
  Secondary source. AMD's definitive agreement of August 6, 2026 to buy Taalas, terms undisclosed, closing expected in Q4 2026. Slides 29 and 34.
- **GadgetScout (2026).** *Etched reaches $10.3bn valuation with SK Hynix backing (August 2, 2026).* https://www.gadgetscout.co.uk/articles/etched-reaches-10-3bn-valuation-with-sk-hynix-backing.html  
  Press, secondary source. A $300M Series C at $10.3B (July 23, 2026), followed in August by $700M at $21B (separate entry); Sohu on TSMC N4P with 144 GB, A0 silicon in June 2026, no independent benchmark; the 500,000 tokens/s claim for an eight-chip server, which is aggregate throughput, not one user's speed. Slide 29.
- **AI Weekly (2026).** *Etched doubles to $21B in $700M round led by Jane Street (August 18, 2026).* https://aiweekly.co/alerts/etched-doubles-to-21b-in-700m-round-led-by-jane-street  
  Press, secondary source. $700M at $21B three weeks after the $300M round at $10.3B, so $1B in July and August 2026 with still no independent benchmark of Sohu; the money-before-silicon row on slide 29. Slides 29 and 34.
- **Implicator (2026).** *Positron raises $875 million at $5 billion before its Asimov chip tapes out (September 10, 2026).* https://www.implicator.ai/positron-raises-875-million-at-5-billion-before-its-asimov-chip-tapes-out.md  
  Press, secondary source. Atlas on Agilex 7 FPGAs with HBM and DDR5 (50+ racks at Oracle); Asimov on N3P with 288 GB to 2.3 TB of LPDDR5X, tape-out end 2026, volume H2 2027, figures from simulation. Slide 29.
- **Marvell Technology (SEC Form 8-K, Ex. 99.1) (2025).** *Marvell to acquire Celestial AI (December 2, 2025).* https://www.sec.gov/Archives/edgar/data/1835632/000119312525305289/d34367dex991.htm  
  Filing (SEC). $1.0B cash and $2.25B in stock up front, up to $2.25B more on revenue milestones; the Photonic Fabric chiplet at 16 Tb/s, 3D co-packaged with XPUs. Slides 29 and 30.
- **Lightmatter (2026).** *Lightmatter product summary (llms.txt).* https://lightmatter.co/llms.txt  
  Vendor page. Passage M1000 (114 Tb/s on a 4,000 mm2 photonic interposer) and the L200 co-packaged optics; Envise placed in a 2030-plus full photonic stack, not cancelled. For L200 rates use the DCD entry: 32 to 34 Tb/s for the L200 and 64 Tb/s for the L200X per chip, more than 200 Tb/s only per multi-chip package. Slide 30.
- **DatacenterDynamics (2025).** *Lightmatter unveils M1000 and L200 Passage photonic interconnects.* https://datacenterdynamics.com/en/news/lightmatter-unveils-m1000-and-l200-passage-photonic-interconnects  
  Press, secondary source. The M1000 interposer at 114 Tb/s over 256 fibers; the L200 co-packaged optical engine at 32 to 34 Tb/s and the L200X at 64 Tb/s per chip, with more than 200 Tb/s claimed only per multi-chip XPU package. Slide 30.
- **TechPowerUp (2024).** *Intel builds world's largest neuromorphic system to enable more sustainable AI (April 17, 2024).* https://Techpowerup.com/321645/intel-builds-worlds-largest-neuromorphic-system-to-enable-more-sustainable-ai  
  Vendor release (republished). Hala Point at Sandia: 1,152 Loihi 2 chips, up to 1.15 billion neurons, up to 20 petaops, 2,600 W maximum. Slide 30.
- **Gonzalez, Huang, Kelber, Nazeer et al. (TU Dresden) (2024).** *SpiNNaker2: a large-scale neuromorphic system for event-based and asynchronous machine learning.* https://arxiv.org/abs/2401.04491  
  Primary paper. 152 Arm cores per chip with local SRAM, 48-chip boards, a multi-million-core machine: the MIMD counterpoint to Loihi 2 among neuromorphic research systems. Slide 30.
- **Modha (IBM) (2023).** *NorthPole: neural inference at the frontier of energy, space, and time (October 19, 2023; companion to Modha et al., Science 382(6668)).* https://modha.org/2023/10/northpole-neural-inference-at-the-frontier-of-energy-space-and-time  
  Author's page for the Science paper, with a free full-text link. 12 nm, 22 billion transistors, 800 mm2, 256 cores, 224 MB on chip and no off-chip memory; the near-memory limit case. Slides 28 and 30.
- **Modha (IBM) (2024).** *Breakthrough low-latency, high-energy-efficiency LLM inference performance using NorthPole (September 26, 2024, IEEE HPEC).* https://modha.org/2024/09/breakthrough-low-latency-high-energy-efficiency-llm-inference-performance-using-northpole  
  Author's summary of an HPEC 2024 paper. A 3B model on 16 NorthPole cards in 2U at 28,356 tokens/s, under 1 ms per token per user, 72.7 times the energy efficiency of 'the next lowest-latency GPU' (IBM's measurement; IBM's blog does not name the GPU, which slide 30 reads as an H100). Slide 30.
- **DeBole, Appuswamy, McGlohon et al. (IBM) (2025).** *A scalable NorthPole system with end-to-end vertical integration for low-latency and energy-efficient LLM inference.* https://arxiv.org/abs/2511.15950  
  Primary paper. 288 NorthPole cards in 18 2U servers: 115 peta-ops at INT4, 3.7 PB/s, 30 kW in one rack, serving 8B models to 28 users at 2.8 ms per token or a 70B model; the step from prototype to rack. Slide 30.

## 9. Measured: specifications, MLPerf, speed and deals (slides 31-34)

- **Peng, Choudhury, Ding, Barker, Geng and Li (UConn, PNNL, Rochester) (2023).** *Evaluating emerging AI/ML accelerators: IPU, RDU, and NVIDIA/AMD GPUs.* https://arxiv.org/abs/2311.04417  
  Independent evaluation paper. A side-by-side specification table (SN10: 40 billion transistors, 640 PCUs and PMUs, 320 MB SRAM, 325 TFLOP/s, 1.5 TB DRAM) and measured kernels on the IPU, the RDU and GPUs. Slides 17 and 31.
- **Emani, Foreman, Sastry, Xie et al. (Argonne) (2023).** *A comprehensive performance study of large language models on novel AI accelerators.* https://arxiv.org/abs/2310.04607  
  Independent evaluation paper. GPT-2 XL, GenSLM and sparse GPT-3 runs on A100, SN30, CS-2, Bow Pod64, Gaudi2 and MI250 at the ALCF; the closest thing to a neutral LLM benchmark for the dataflow machines, which skipped MLPerf. Slides 32 and 35.
- **Mattson et al. (2020).** *MLPerf Training benchmark (MLSys 2020).* https://arxiv.org/abs/1910.01500  
  Primary paper. The time-to-train method, the reference models and the closed and open divisions behind every Training round on the participation chart. Slide 32.
- **MLCommons (2022).** *MLPerf Training results repositories (training_results_v0.5 to v6.0; this link is v2.1, November 2022).* https://github.com/mlcommons/training_results_v2.1  
  Benchmark consortium, open data. One GitHub repository per round, with a directory per submitter and systems/*.json per system; the primary record for the Training dots on slide 32. v2.1 is the round with neither Google nor any IPU entry; change the version in the URL for other rounds. Slides 12, 18 and 32.
- **MLCommons (2024).** *MLPerf Inference results repositories (inference_results_v0.5 to v6.0; this link is v4.0, March 2024).* https://github.com/mlcommons/inference_results_v4.0  
  Benchmark consortium, open data. The primary record for the Inference circles on slide 32: TPU entries only in v0.5, v3.1, v4.0 and v5.0 (Google's v4.1, v5.1 and v6.0 entries are NVIDIA systems); v4.0 is Qualcomm's last round and has TPU v5e and Gaudi 2. Slides 24 and 32.
- **MLCommons (2025).** *MLPerf Training v5.0 results (June 4, 2025).* https://mlcommons.org/2025/06/mlperf-training-v5-0-results  
  Benchmark consortium, open. Twenty submitters with AMD new; TPU Trillium the one non-GPU processor among the twelve; Google's last Training round before it skipped 5.1. Slide 32.
- **MLCommons (2026).** *Supplemental results discussion for MLPerf Training v6.0 (June 2026).* https://mlcommons.org/wp-content/uploads/2026/06/MLPerf-Training-v6.0-Supplemental-Discussion-UNDER-EMBARGO-UNTIL-6_16_26-8_00-AM-PT-1.pdf  
  Benchmark consortium, open. The submitters' own notes for Training 6.0: Google is listed as a submitter but only AMD and NVIDIA accelerators are named; the basis for 'no TPU result in 6.0'. Slides 12 and 32.
- **Artificial Analysis (2026).** *gpt-oss-120B (high): API provider benchmarks (live page, read November 2026).* https://artificialanalysis.ai/models/gpt-oss-120b/providers  
  Independent benchmark service. Sixteen providers of one model: Cerebras first answer in about 2.1 s at $0.39 per million tokens, the highest price listed; Groq and SambaNova slower to first answer. Read it with a date; it changes. Slide 33.
- **Patel and Nishball (SemiAnalysis) (2024).** *Groq inference tokenomics: speed, but at what cost? (February 21, 2024).* https://newsletter.semianalysis.com/p/groq-inference-tokenomics-speed-but  
  Analyst note, secondary source. 576 chips (8 racks of 9 servers of 8) to serve Mixtral, 230 MB SRAM and about 725 mm2 on GlobalFoundries 14 nm per chip, against an H100 with about $1,150 of HBM; the cost-per-token argument. Slides 8, 16 and 33.
- **South China Morning Post (2025).** *Google, Anthropic unveil cloud deal worth tens of billions of dollars (October 24, 2025).* https://www.scmp.com/tech/big-tech/article/3330143/google-anthropic-unveil-cloud-deal-worth-tens-billions-dollars  
  Press, secondary source. Up to one million TPUs for Anthropic and over a gigawatt online in 2026; the first row of the deals table. Slides 12 and 34.
- **Analytics India Magazine (2025).** *Broadcom reveals $21 billion Google TPU order from Anthropic (December 12, 2025).* https://analyticsindiamag.com/ai-news-updates/broadcom-reveals-21-billion-google-tpus-order-from-anthropic/  
  Press, secondary source. From Broadcom's Q4 FY2025 call: about $10B of TPU orders in one quarter and $11B more for delivery in late 2026, the customer named as Anthropic. Slides 12, 23 and 34.
- **Dataconomy (2026).** *Meta signs multibillion-dollar deal to rent Google TPUs for AI training (February 27, 2026).* https://dataconomy.com/2026/02/27/meta-signs-multibillion-dollar-deal-to-rent-google-tpus-for-ai-training/  
  Press, secondary source (relaying Reuters, February 26, 2026). Meta leasing TPUs through Google Cloud, with outright purchases discussed for the following year. Slides 12 and 34.
- **SiliconANGLE (2025).** *AWS opens $11B Project Rainier data center campus built for Anthropic (October 29, 2025).* https://siliconangle.com/2025/10/29/aws-opens-11b-project-rainier-data-center-campus-built-anthropic/  
  Press, secondary source. Nearly 500,000 Trainium2 in seven Indiana buildings, over a million targeted by the end of 2025 (the 1M+ AWS reported in December 2025 was fleet-wide, with Anthropic on over 500,000), more than 2.2 GW planned. Slides 21 and 34.
- **Broadcom (SEC Form 8-K, Ex. 99) (2025).** *Broadcom announces fourth quarter and fiscal year 2025 financial results (December 11, 2025).* https://www.sec.gov/Archives/edgar/data/1730168/000173016825000116/avgo-11022025x8kxex99.htm  
  Filing (SEC). AI semiconductor revenue up 74 percent in Q4 FY2025 and $8.2B guided for Q1 FY2026, driven by custom accelerators and Ethernet switches; the XPU business in one number. Slides 23 and 34.
- **TrendForce (2025).** *Strong demand from CSPs and sovereign cloud to drive over 20% growth in AI server shipments by 2026 (October 30, 2025).* https://www.trendforce.com/presscenter/news/20251030-12762.html  
  Analyst press release, secondary source. NVIDIA at about 70 percent of the 2025 AI-chip market and custom-ASIC shipments expected to pass GPU shipments in 2026. Slides 34 and 36.
- **Crunchbase News (2026).** *Record-high US semiconductor startup funding in 2025 (January 6, 2026).* https://news.crunchbase.com/venture/record-high-us-semiconductor-startup-funding-eoy-2025  
  Press (data provider), secondary source. About $6.2B of US semiconductor startup equity in 2025, up 85 percent, nearly half in three rounds: Cerebras $1.1B, PsiQuantum $1B, Groq $750M. Slide 34.

## 10. Wrap-up (slides 35-37)

- **Emani, Xie, Raskar, Sastry, ... Papka (Argonne) with Cerebras, SambaNova, Graphcore and Groq (2022).** *A comprehensive evaluation of novel AI accelerators for deep learning workloads (PMBS 2022, SC22 workshops).* https://sc22.supercomputing.org/proceedings/workshops/workshop_pages/ws_pmbsf120.html  
  Workshop paper (proceedings page). The first peer-reviewed side-by-side of the four dataflow machines on the same science workloads at the ALCF testbed; what the programming effort looked like from a user's side. Slides 35 and 37.
- **Lattner, Amini, Bondhugula, Cohen, Davis, Pienaar, Riddle, Shpeisman, Vasilache and Zinenko (2021).** *MLIR: scaling compiler infrastructure for domain specific computation (CGO 2021).* https://arxiv.org/abs/2002.11054  
  Primary paper. The compiler substrate under StableHLO, IREE, TT-Forge and most startup stacks; why a new chip in 2026 needs less compiler work than one in 2017. Slides 19 and 35.
- **Chen, Moreau, Jiang, Zheng et al. (2018).** *TVM: an automated end-to-end optimizing compiler for deep learning (OSDI 2018).* https://arxiv.org/abs/1802.04799  
  Primary paper. The auto-tuning tensor compiler that several NPU vendors built on; the alternative to writing every kernel by hand. Slide 35.
- **Google Open Source Blog (2023).** *OpenXLA is ready to accelerate and simplify ML development (March 8, 2023).* https://opensource.googleblog.com/2023/03/openxla-is-ready-to-accelerate-and-simplify-ml-development.html  
  Vendor blog. XLA, StableHLO and IREE opened up, with AWS, Cerebras, Graphcore, Intel, Meta and NVIDIA among the co-developers; when the TPU's compiler became a shared target. Slides 12 and 35.
- **vLLM project (2025).** *Introducing vLLM hardware plugin, best practice from Ascend NPU (May 12, 2025).* https://vllm.ai/blog/2025-05-12-hardware-plugin  
  Open-source project blog. The platform-plugin mechanism (RFC 11162) used by vllm-ascend and vllm-spyre; how non-NVIDIA silicon reaches production LLM serving without forking. Slides 25 and 35.
- **Quach (The Register) (2020).** *Two startups enter, one leaves: Intel kills off much-delayed Nervana AI training chip, pushes on with Habana (January 31, 2020).* https://www.theregister.com/2020/01/31/intel_kills_spring_crest/  
  Press, secondary source. Intel ends the NNP-T (Spring Crest) weeks after buying Habana; Nervana had cost $350M in 2016; an early example of an acquirer choosing between two accelerator lines. Slides 24 and 35.
- **MIPS (PR Newswire) (2021).** *Wave Computing and MIPS emerge from Chapter 11 bankruptcy (March 1, 2021).* https://prnewswire.com/news-releases/wave-computing-and-mips-emerge-from-chapter-11-bankruptcy-301237051.html  
  Vendor press release. The dataflow-chip company Wave leaves bankruptcy as MIPS under Tallwood ($61M winning bid), turning to RISC-V; the first of the dataflow startups to fail. Slides 5 and 35.
- **corsix.org (2025).** *Esperanto lives on at AINekko (October 29, 2025).* https://www.corsix.org/content/esperanto-lives-on  
  Independent analysis, secondary source. Esperanto's July 2025 shutdown (staff poached at up to four times the pay) and the ET-SoC-1's 1,000-plus RISC-V cores and 32 GB of LPDDR4x, now open-sourced by AINekko. Slide 35.
