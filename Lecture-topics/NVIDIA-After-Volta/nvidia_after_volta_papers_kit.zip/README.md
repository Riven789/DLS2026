# Reading list: NVIDIA GPU Architectures after Volta

Companion papers to the deck and its lecture notes, grouped by section.
`reading_list.csv` and `reading_list.bib` hold the same list as data; `fetch_papers.sh` downloads
every arXiv entry into one folder per section and zips the result (`bash fetch_papers.sh`).
Entries without an arXiv identifier are listed with a URL and must be fetched by hand.

## 1. Overview: nine years after Volta (slides 1-3)

- **Dally, Keckler and Kirk (2021).** *Evolution of the graphics processing unit (GPU).* https://doi.org/10.1109/MM.2021.3113475  
  IEEE Micro 41(6). The architects' retrospective from G80 to Ampere; the starting point for everything after Volta.
- **Mann (The Register) (2024).** *Chipmakers' Computex roadmaps: NVIDIA's yearly cadence (June 2024).* https://www.theregister.com/2024/06/05/chipmakers_computex_roadmaps  
  Press, secondary source. The June 2, 2024 keynote in which NVIDIA laid out the annual cadence (Blackwell Ultra 2025, Rubin 2026, Rubin Ultra 2027), first signaled to investors in October 2023. Slide 3.
- **Lockwood (2026).** *GTC 2026 recap (blog, March 2026).* https://blog.glennklockwood.com/2026/03/gtc-2026-recap.html  
  Independent analyst notes, open. The clearest account of what GTC 2026 changed: Rubin CPX gone, Kyber redesigned, Feynman and the Rosa CPU, co-packaged optics. Slides 3 and 26.
- **Lockwood (2025).** *B200 (processor garden page).* https://glennklockwood.com/garden/processors/B200  
  Independent, open. A sourced table of every Blackwell variant's announced and shipping specifications; the reference for the announced-versus-shipped story.
- **Lockwood (2026).** *B300 (processor garden page).* https://glennklockwood.com/garden/processors/B300  
  Independent, open. GB300 versus HGX B300 specifications, including the FP64 cut.
- **Lockwood (2026).** *Rubin R200 (processor garden page).* https://glennklockwood.com/garden/processors/R200  
  Independent, open. The provenance of every Rubin number, with the NVL144 to NVL72 history.
- **Micikevicius et al. (2017).** *Mixed precision training.* https://arxiv.org/abs/1710.03740  
  ICLR 2018. The FP16 training recipe (master weights, loss scaling) that every later format rung builds on; the Volta-era baseline for slide 10.

## 2. Turing (slides 4-5)

- **NVIDIA (2018).** *NVIDIA Turing GPU architecture whitepaper.* https://images.nvidia.com/aem-dam/Solutions/design-visualization/technologies/turing-architecture/NVIDIA-Turing-Architecture-Whitepaper.pdf  
  Vendor whitepaper. TU102 Table 1 (18.6B transistors, 754 mm2), the SM with RT cores and INT8/INT4 tensor cores, mesh shading, variable-rate shading, DLSS. Slide 4.
- **NVIDIA (2018).** *Tesla T4 datasheet.* https://nvidia.com/content/dam/en-zz/Solutions/Data-Center/tesla-t4/t4-tensor-core-datasheet-951643.pdf  
  Vendor datasheet. 2,560 CUDA cores, 320 tensor cores, 65 TFLOP/s FP16, 130 TOPS INT8, 260 TOPS INT4, 16 GB GDDR6 at 300 GB/s, 70 W. Slide 5.
- **Jia, Maggioni, Smith and Scarpazza (2019).** *Dissecting the NVidia Turing T4 GPU via microbenchmarking.* https://arxiv.org/abs/1903.07486  
  The Volta microbenchmark methodology applied to the T4: cache latencies, the integer tensor modes, clock behavior under the 70 W limit. Slide 5.
- **Jia, Maggioni, Staiger and Scarpazza (2018).** *Dissecting the NVIDIA Volta GPU architecture via microbenchmarking.* https://arxiv.org/abs/1804.06826  
  The baseline measurements (shared 19 cycles, L1 28, L2 about 193, global 375 to 1,029) that the later papers compare against.
- **NVIDIA (2020).** *NVIDIA DLSS 2.0: a big leap in AI rendering (GTC 2020 talk and developer page).* https://developer.nvidia.com/blog/nvidia-dlss-2-0-a-big-leap-in-ai-rendering/  
  Vendor blog. The temporal network that made tensor cores a standard graphics stage. Slide 5.

## 3. Ampere (slides 6-10)

- **NVIDIA (2020).** *NVIDIA A100 Tensor Core GPU architecture (Ampere whitepaper).* https://images.nvidia.com/aem-dam/en-zz/Solutions/data-center/nvidia-ampere-architecture-whitepaper.pdf  
  Vendor whitepaper. GA100 Table 4 (54.2B transistors, 826 mm2, 108 of 128 SMs), the third-generation tensor core, TF32, BF16, 2:4 sparsity, MIG, asynchronous copy, NVLink 3, DGX A100 appendix. Slides 6-9.
- **Choquette and Gandhi (2020).** *NVIDIA A100 GPU: performance and innovation (Hot Chips 32).* https://hc32.hotchips.org/assets/program/conference/day1/HotChips2020_GPU_NVIDIA_Choquette_v01.pdf  
  Conference slides, open. The design talk: the SM, the tensor core data path, the L2 and the NVLink 3 fabric. Slide 7.
- **Choquette, Gandhi, Giroux, Stam and Krashinsky (2021).** *NVIDIA A100 Tensor Core GPU: performance and innovation.* https://doi.org/10.1109/MM.2021.3061394  
  IEEE Micro 41(2). The peer-reviewed A100 paper: tensor-core generations, sparsity, MIG, asynchronous data movement.
- **Abdelkhalik, Arafa, Santhi and Badawy (2022).** *Demystifying the Nvidia Ampere architecture through microbenchmarking and instruction-level analysis.* https://arxiv.org/abs/2208.11174  
  Measured latencies and throughputs on the A100, including the tensor-core instructions and the asynchronous copy path. Slides 7-8 and 15.
- **Tom's Hardware (2020).** *Nvidia RTX 30-series Ampere architecture deep dive.* https://www.tomshardware.com/features/nvidia-ampere-architecture-deep-dive  
  Press, secondary source. GA102's dual-FP32 datapath, Samsung 8N, 28.3B transistors on 628 mm2: the graphics-die side of slide 9.
- **Mishra, Latorre, Pool, Stosic, Stosic, Venkatesh, Yu and Micikevicius (2021).** *Accelerating sparse deep neural networks.* https://arxiv.org/abs/2104.08378  
  The 2:4 structured-sparsity recipe (prune, fine-tune, 2x on Ampere tensor cores) behind every sparse peak since 2020. Slide 8.
- **Kalamkar et al. (Intel) (2019).** *A study of BFLOAT16 for deep learning training.* https://arxiv.org/abs/1905.12322  
  Why 8 exponent bits and 7 mantissa bits suffice for training without loss scaling; the case for the BF16 rung on slide 10.
- **NVIDIA (2020).** *NVIDIA Multi-Instance GPU user guide.* https://docs.nvidia.com/datacenter/tesla/mig-user-guide/index.html  
  Vendor documentation. The seven-instance partitioning of the A100 (and later GPUs): what an instance owns and how it is configured. Slide 8.
- **NVIDIA (2020).** *HGX A100 datasheet.* https://www.nvidia.com/content/dam/en-zz/Solutions/Data-Center/HGX/pdf/nvidia-hgx-a100-datasheet.pdf  
  Vendor datasheet. The 8-GPU board: 600 GB/s NVLink 3 per GPU, 4.8 TB/s aggregate through six NVSwitches. Slide 9.

## 4. Hopper (slides 11-15)

- **NVIDIA (2022).** *NVIDIA H100 Tensor Core GPU architecture (GTC 2022 whitepaper).* https://www.ece.lsu.edu/koppel/gp/refs/gtc22-whitepaper-hopper.pdf  
  Vendor whitepaper (mirror; original at resources.nvidia.com). GH100 Table 3, thread block clusters, DSMEM, TMA, asynchronous transaction barriers, Transformer Engine, DPX, NVLink 4; note that its peaks are preliminary (FP64 30, later 34). Slides 11-13.
- **NVIDIA (2023).** *H100 Tensor Core GPU datasheet.* https://openzeka.com/wp-content/uploads/2023/12/h100-datasheet-1.pdf  
  Vendor datasheet (mirror). The shipping peaks with the sparsity footnote: TF32 494/989, FP16 989/1,979, FP8 1,979/3,958 dense/sparse; SXM, PCIe and NVL variants. Slide 12.
- **Choquette (2023).** *NVIDIA Hopper H100 GPU: scaling performance.* https://ieeexplore.ieee.org/document/10070122  
  IEEE Micro 43(3). The peer-reviewed Hopper paper: the SM, the fourth-generation tensor core, FP8, clusters and the NVLink Switch System.
- **Andersch et al. (NVIDIA) (2022).** *NVIDIA Hopper architecture in-depth (developer blog).* https://developer.nvidia.com/blog/nvidia-hopper-architecture-in-depth/  
  Vendor blog. The most readable account of TMA, DSMEM, wgmma and the Transformer Engine. Slide 13.
- **Micikevicius, Stosic, Burgess, Cornea, Dubey, Grisenthwaite, Ha, Heinecke, Judd, Kamalu, Mellempudi, Oberman, Shoeybi, Siu and Wu (2022).** *FP8 formats for deep learning.* https://arxiv.org/abs/2209.05433  
  NVIDIA, Arm and Intel's joint proposal of E4M3 and E5M2 and the per-tensor scaling recipe, with training results matching BF16. Slide 12.
- **Luo, Fan, Li, Du, Wang and Chu (2024).** *Benchmarking and dissecting the Nvidia Hopper GPU architecture.* https://arxiv.org/abs/2402.13499  
  Microbenchmarks of the H100: DPX, DSMEM latency, FP8 tensor throughput, wgmma, clusters. Slides 13 and 15.
- **NVIDIA (2023).** *NVIDIA supercharges Hopper, the world's leading AI computing platform (press release, November 13, 2023).* https://nvidianews.nvidia.com/news/nvidia-supercharges-hopper-the-worlds-leading-ai-computing-platform  
  Vendor press release. The H200: 141 GB of HBM3e at 4.8 TB/s, availability Q2 2024. Slide 14.
- **NVIDIA (2023).** *GH200 Grace Hopper Superchip datasheet.* https://www.amax.com/content/files/2023/12/NVIDIA_GH200_Grace_Hopper_Superchip_Datasheet.pdf  
  Vendor datasheet (mirror). Grace (72 Neoverse V2 cores, 480 GB LPDDR5X at up to 512 GB/s), NVLink-C2C at 900 GB/s, 96 GB HBM3 or 144 GB HBM3e. Slide 14.
- **NVIDIA (2024).** *Grace CPU performance tuning guide.* https://docs.nvidia.com/grace-performance-tuning-guide.pdf  
  Vendor documentation. The Grace microarchitecture and memory system for readers who want the CPU side of the superchip.
- **NVIDIA (2023).** *AWS and NVIDIA announce strategic collaboration (press release, November 2023).* https://nvidianews.nvidia.com/news/aws-nvidia-strategic-collaboration-for-generative-ai  
  Vendor press release. The GH200 NVL32 rack and Project Ceiba: the first 32-GPU NVLink domains with Grace Hopper.
- **Shah, Bikshandi, Zhang, Thakkar, Ramani and Dao (2024).** *FlashAttention-3: fast and accurate attention with asynchrony and low-precision.* https://arxiv.org/abs/2407.08691  
  How TMA, wgmma and FP8 are used in practice: attention at about 75 percent of the H100's FP16 peak. Slides 13 and 29.
- **NVIDIA (2022).** *NVIDIA NVLink and NVSwitch (product page, third generation).* https://www.nvidia.com/en-us/data-center/nvlink/  
  Vendor page. NVLink 4 at 900 GB/s, the 64-port NVSwitch with SHARP, and the 256-GPU NVLink Switch System. Slide 14.

## 5. Ada Lovelace (slide 16)

- **NVIDIA (2022).** *NVIDIA Ada GPU architecture whitepaper.* https://images.nvidia.com/aem-dam/Solutions/geforce/ada/nvidia-ada-gpu-architecture.pdf  
  Vendor whitepaper. AD102 (76.3B transistors, 608.5 mm2, 144 SMs, 96 MB L2), shader execution reordering, third-generation RT cores, DLSS 3, fourth-generation tensor cores with FP8. Slide 16.
- **Supermicro and NVIDIA (2023).** *NVIDIA L40S systems datasheet.* https://www.supermicro.com/datasheet/datasheet_NVIDIA_L40S_Systems.pdf  
  Vendor datasheet. L40S peaks (91.6 TFLOP/s FP32, 733 dense FP8, 48 GB at 864 GB/s, 350 W). Slide 16.

## 6. Blackwell and Blackwell Ultra (slides 17-22)

- **NVIDIA (2024).** *NVIDIA Blackwell platform arrives to power a new era of computing (press release, March 18, 2024).* https://nvidianews.nvidia.com/news/nvidia-blackwell-platform-arrives-to-power-a-new-era-of-computing  
  Vendor press release. 208B transistors, the 10 TB/s NV-HBI, fifth-generation tensor cores, NVLink 5, the GB200 NVL72. Slide 17.
- **NVIDIA GmbH (2024).** *Blackwell customer deck (March 2024).* https://mcomputers.cz/wp-content/uploads/2024/04/NVIDIA-Blackwell-Praha-PDF.pdf  
  Vendor slides (mirror). The original B100/B200/GB200 specifications (FP64 30/40/45 TFLOP/s, 192 GB, 8 TB/s, PCIe 6) that later shipped lower; the primary source for slide 17's announced-versus-shipped comparison.
- **NVIDIA (2024).** *NVIDIA Blackwell architecture technical brief.* https://resources.nvidia.com/en-us-blackwell-architecture  
  Vendor document (registration). The official architecture brief: tensor-core formats, decompression and RAS engines, confidential computing.
- **Tirumala and Wong (2024).** *NVIDIA Blackwell platform: advancing generative AI and accelerated computing (Hot Chips 36).* https://doi.org/10.1109/HCS61935.2024.10665247  
  Conference talk, IEEE Xplore. The official Blackwell presentation: the two-die design, NV-HBI, NVLink 5 and the rack.
- **NVIDIA (2025).** *GB200 NVL72 (product page).* https://www.nvidia.com/en-us/data-center/gb200-nvl72/  
  Vendor page. The shipping rack specifications with dense and sparse footnotes: 1,440/720 PFLOP/s FP4, 2,880 TFLOP/s FP64, 13.4 TB HBM3e, 130 TB/s NVLink. Slide 19.
- **Lenovo (2026).** *ThinkSystem NVIDIA B200 180GB 1000W GPU (product guide).* https://lenovopress.lenovo.com/lp2226-thinksystem-nvidia-b200-180gb-1000w-gpu  
  Vendor documentation. The HGX B200 as shipped: 180 GB, 7.7 TB/s, 37 TFLOP/s FP64, PCIe 5. Slide 17.
- **heise online (2024).** *Blackwell: Nvidia unveils its next generation of AI accelerators (page 2).* https://heise.de/en/news/Blackwell-Nvidia-unveils-its-next-generation-of-AI-accelerators-9782399.html?seite=2  
  Press, secondary source. The NVLink Switch chip (7.2 TB/s, 50B transistors) and the B100/B200/GB200 power figures. Slide 19.
- **Mann (The Register) (2024).** *Nvidia's future in scientific computing hinges on a melding of AI and HPC (May 2024).* https://www.theregister.com/2024/05/22/nvidias_future_in_scientific_computing/  
  Press, secondary source. The Blackwell FP64 debate as it happened, with NVIDIA's position. Slide 21.
- **The Register (2024).** *Nvidia confirms Blackwell mask change (August 2024).* https://www.theregister.com/2024/08/29/nvidia_blackwell_manufacturing/  
  Press, secondary source. The Q2 FY25 call: a mask change to improve yield, no functional change, ramp in Q4 2024. Slide 17.
- **Neowin (2024).** *Microsoft Azure is the first hyperscaler with NVIDIA's Blackwell GB200 (October 2024).* https://www.neowin.net/amp/microsoft-azure-is-the-first-hyperscaler-to-have-nvidias-blackwell-system-with-gb200/  
  Press, secondary source. The first GB200 deployment, October 8, 2024. Slide 19.
- **Jarmusch, Graddon and Chandrasekaran (2025).** *Dissecting the NVIDIA Blackwell architecture with microbenchmarks.* https://arxiv.org/abs/2507.10789  
  Consumer Blackwell (RTX 5080) against the H100: the first independent measurements of the fifth-generation tensor core.
- **Jarmusch and Chandrasekaran (2025).** *Microbenchmarking NVIDIA's Blackwell architecture: tensor memory, tcgen05 and the B200.* https://arxiv.org/abs/2512.02189  
  The B200 measured: 148 SMs, 256 KB tensor memory per SM, tcgen05 issue, 44.8 TFLOP/s FP64. The source for the SM counts the datasheets omit. Slides 15, 17, 18.
- **NVIDIA (2025).** *Inside NVIDIA Blackwell Ultra: the chip powering the AI factory era (developer blog, August 2025).* https://developer.nvidia.com/blog/inside-nvidia-blackwell-ultra-the-chip-powering-the-ai-factory-era/  
  Vendor blog. 160 SMs, 288 GB HBM3e, 15/20 PFLOP/s FP4, the doubled SFU exponential rate, PCIe 6. Slide 20.
- **Tom's Hardware (2025).** *Nvidia shares Blackwell Ultra's secrets at Hot Chips 2025.* https://www.tomshardware.com/pc-components/gpus/nvidia-shares-blackwell-ultras-secrets-nvfp4-boost-detailed-and-pcie-6-0-support  
  Press, secondary source. The Hot Chips 37 table with the B300's 1.39 TFLOP/s FP64. Slides 20-21.
- **NVIDIA (2025).** *GB300 NVL72 (product page).* https://www.nvidia.com/en-au/data-center/gb300-nvl72  
  Vendor page. 1,440/1,080 PFLOP/s FP4, 100 TFLOP/s FP64 per rack, 20 TB HBM3e, 37 TB fast memory. Slide 20.
- **NVIDIA (2025).** *Blackwell Ultra datasheet.* https://resources.nvidia.com/en-us-blackwell-architecture/blackwell-ultra-datasheet  
  Vendor datasheet (registration). GB300 and HGX B300 per-GPU figures.
- **Tom's Hardware (2025).** *NVIDIA's newest top-tier AI supercomputers deployed for the first time at CoreWeave (July 2025).* https://www.tomshardware.com/tech-industry/artificial-intelligence/nvidias-newest-top-tier-ai-supercomputers-deployed-for-the-first-time-grace-blackwell-ultra-superchip-systems-deployed-at-coreweave  
  Press, secondary source. The first GB300 NVL72 racks, July 3, 2025. Slide 20.
- **NVIDIA (2025).** *Introducing NVFP4 for efficient and accurate low-precision inference (developer blog, June 2025).* https://developer.nvidia.com/blog/introducing-nvfp4-for-efficient-and-accurate-low-precision-inference/  
  Vendor blog. The format: E2M1 values, 16-element blocks with an E4M3 scale and an FP32 per-tensor scale; the accuracy claims. Slide 18.
- **Abecassis et al. (NVIDIA) (2025).** *Pretraining large language models with NVFP4.* https://arxiv.org/abs/2509.25149  
  A 12B-parameter model trained on 10 trillion tokens in NVFP4 matching the FP8 loss curve; the recipe (block scaling, stochastic rounding, mixed layers). Slide 18.
- **Rouhani et al. (2023).** *Microscaling data formats for deep learning.* https://arxiv.org/abs/2310.10537  
  The OCP MX formats (MXFP8, MXFP6, MXFP4) from Microsoft, AMD, Intel, Meta, NVIDIA and others: 32-element blocks with an E8M0 scale. Slides 10 and 18.
- **Open Compute Project (2023).** *OCP microscaling formats (MX) specification version 1.0.* https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf  
  Standard text. The normative definition of the MX formats.
- **Ozaki, Ogita, Oishi and Rump (2012).** *Error-free transformations of matrix multiplication by using fast routines of matrix multiplication and its applications.* https://doi.org/10.1007/s11075-011-9478-1  
  Numerical Algorithms 59. The Ozaki scheme: splitting floating-point matrices into exactly representable slices so that lower-precision (or integer) GEMMs reproduce high-precision results; the basis of FP64 emulation on tensor cores. Slide 21.
- **Ootomo, Ozaki and Yokota (2024).** *DGEMM on integer matrix multiplication unit.* https://doi.org/10.1177/10943420241239588  
  IJHPCA 38(4); arXiv 2306.11975. FP64 matrix multiply on INT8 tensor cores with the Ozaki scheme, faster than native FP64 on consumer GPUs: the method cuBLAS adopted. Slide 21.
- **NVIDIA (2025).** *Unlocking tensor core performance with floating-point emulation in cuBLAS (developer blog, October 2025).* https://developer.nvidia.com/blog/unlocking-tensor-core-performance-with-floating-point-emulation-in-cublas/  
  Vendor blog. FP64 emulation on Blackwell's INT8 tensor cores (Ozaki scheme) shipped in CUDA 13.0 Update 2: how it is enabled and the claim of up to 2.3x native DGEMM on GB200 NVL72. Slides 21 and 29.
- **NVIDIA (2025).** *Boosting matrix multiplication speed and flexibility with NVIDIA cuBLAS 12.9 (developer blog, May 2025).* https://developer.nvidia.com/blog/boosting-matrix-multiplication-speed-and-flexibility-with-nvidia-cublas-12-9/  
  Vendor blog. The 12.9 release: FP32 emulation on BF16 tensor cores, block-scaled FP8/FP4 GEMMs, and the note that FP64 emulation was still under development. Slide 29.
- **The Register (2024).** *Nvidia's DGX GB200 NVL72 (March 2024).* https://www.theregister.com/2024/03/21/nvidia_dgx_gb200_nvk72  
  Press, secondary source. The rack's 120 kW and 1,200 W per GPU. Slide 22.

## 7. Rubin and Vera (slides 23-26)

- **Tom's Hardware (2025).** *Nvidia announces Rubin GPUs in 2026, Rubin Ultra in 2027, Feynman after (GTC, March 2025).* https://www.tomshardware.com/pc-components/gpus/nvidia-announces-rubin-gpus-in-2026-rubin-ultra-in-2027-feynam-after  
  Press, secondary source. The GTC 2025 numbers: Vera Rubin NVL144 (3.6 EF FP4, 13 TB/s HBM4, 260 TB/s), Rubin Ultra NVL576 (15 EF, 600 kW), Feynman. Slides 23, 25, 26.
- **NVIDIA (2025).** *NVIDIA unveils Rubin CPX (press release, September 9, 2025).* https://nvidianews.nvidia.com/news/nvidia-unveils-rubin-cpx-a-new-class-of-gpu-designed-for-massive-context-inference  
  Vendor press release. The prefill GPU as announced: 128 GB GDDR7, 30 PFLOP/s NVFP4, the NVL144 CPX rack. Slide 26.
- **RCR Tech (2026).** *Nvidia reportedly revives Rubin CPX (September 2026).* https://rcrtech.com/semiconductor-news/nvidia-reportedly-revives-rubin-cpx/  
  Press, secondary source, unconfirmed. The report of a CPX revival with HBM4 for 2027. Slide 26.
- **NVIDIA (2026).** *NVIDIA kicks off the next generation of AI with Rubin: six new chips, one incredible AI supercomputer (press release, January 5, 2026).* https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Kicks-Off-the-Next-Generation-of-AI-With-Rubin--Six-New-Chips-One-Incredible-AI-Supercomputer/default.aspx  
  Vendor press release. The CES announcement: Vera, Rubin, the NVLink 6 switch, ConnectX-9, BlueField-4, Spectrum-6; the return to the NVL72 name. Slides 23-24.
- **ServeTheHome (2026).** *NVIDIA launches next-generation Rubin AI compute platform at CES 2026.* https://www.servethehome.com/nvidia-launches-next-generation-rubin-ai-compute-platform-at-ces-2026/  
  Press, secondary source. The keynote slides with the 336B transistor count, the 22 TB/s HBM4 figure of the time, and Vera details. Slide 23.
- **Tom's Hardware (2026).** *Nvidia's seven-chip Vera Rubin platform turns the data center into an AI factory (GTC, March 2026).* https://www.tomshardware.com/tech-industry/artificial-intelligence/nvidias-seven-chip-vera-rubin-platforms-turns-the-data-center-into-an-ai-factory  
  Press, secondary source. GTC 2026: the platform with the Groq 3 LPX added, pod-level figures. Slide 24.
- **StorageReview (2026).** *NVIDIA GTC 2026: Rubin GPUs, Groq LPUs, Vera CPUs.* https://www.storagereview.com/news/nvidia-gtc-2026-rubin-gpus-groq-lpus-vera-cpus-and-what-nvidia-is-building-for-trillion-parameter-inference  
  Press, secondary source. The Groq 3 LPX and the Vera rack as presented at GTC 2026. Slides 24 and 26.
- **NVIDIA (2026).** *Vera Rubin NVL72 (product page, revised September-October 2026).* https://www.nvidia.com/en-us/data-center/vera-rubin-nvl72  
  Vendor page. The current specifications: 19.2 TB/s HBM4 per GPU, 3 TB/s NVLink 6, 216 TB/s per rack, 2.4 PFLOP/s FP64, 33 TFLOP/s FP64 per GPU. Slides 23 and 25.
- **Hardware Busters (2026).** *Nvidia quietly lowers Vera Rubin HBM4 bandwidth and the HGX NVL8 loses a quarter of it (October 2026).* https://hwbusters.com/news/nvidia-quietly-lowers-vera-rubin-hbm4-bandwidth-and-the-hgx-nvl8-loses-a-quarter-of-it/  
  Press, secondary source. The old-versus-new table of the September 2026 revision, dated with the Wayback Machine. Slide 25.
- **Wccftech (2026).** *NVIDIA's official statement on the Vera Rubin spec change (October 29, 2026).* https://wccftech.com/nvidia-official-statement-on-vera-rubin-spec-change/  
  Press, secondary source. NVIDIA's statement that the earlier figures were preliminary architectural targets. Slide 25.
- **TechPowerUp (2026).** *NVIDIA cuts HBM4 speed and NVLink bandwidth targets for Vera Rubin.* https://www.techpowerup.com/354133/nvidia-cuts-hbm4-speed-and-nvlink-bandwidth-targets-for-vera-rubin  
  Press, secondary source. The pin-rate arithmetic behind the revision.
- **Hot Chips (2026).** *Hot Chips 38 program (August 2026).* https://hc2026.hotchips.org/program/  
  Conference program. The Rubin GPU talk (Mandal, Dash, Dimitrov) and the Vera CPU talk (Evans, Xekalakis). Slides 23-24.
- **ServeTheHome (2026).** *NVIDIA Vera Rubin NVL72 rack at Hot Chips 2026.* https://www.servethehome.com/nvidia-vera-rubin-nvl72-rack-at-hot-chips-2026/  
  Press, secondary source. The rack as presented: NVLink 6 switch with 130 TFLOP/s of in-network compute, 800 V DC, cable-free trays. Slide 25.
- **ServeTheHome (2026).** *NVIDIA Vera CPU at Hot Chips 2026.* https://www.servethehome.com/nvidia-vera-cpu-at-hot-chips-2026/  
  Press, secondary source. The Olympus core, spatial multithreading, the six-die package. Slide 24.
- **NVIDIA (2026).** *Vera Rubin ramps into full production (press release, May 31, 2026).* https://nvidianews.nvidia.com/news/vera-rubin-full-production-agentic-ai-factory  
  Vendor press release. The GTC Taipei statement: production shipments starting in the fall. Slide 23.
- **NVIDIA (2026).** *Q2 fiscal 2027 financial results (8-K, August 26, 2026).* https://www.sec.gov/Archives/edgar/data/0001045810/000104581026000073/q2fy27pr.htm  
  Regulatory filing. Vera Rubin racks at CoreWeave, Google Cloud, Azure, OCI and Nebius; Groq 3 LPX in production. Slide 23.
- **Tom's Hardware (2026).** *Nvidia expects to sell $20 billion of Vera Rubin hardware this quarter.* https://www.tomshardware.com/tech-industry/artificial-intelligence/nvidia-expects-to-sell-usd20-billion-worth-of-vera-rubin-hardware-this-quarter-would-account-for-20-percent-of-data-center-revenue-its-fastest-ramp-in-company-history  
  Press, secondary source. First revenue racks in August 2026 and the Q3 FY27 guidance. Slide 23.
- **CoreWeave (2026).** *CoreWeave delivers NVIDIA Vera Rubin NVL72 performance at production scale, starting with Cognition (press release, September 2026).* https://investors.coreweave.com/news/news-details/2026/CoreWeave-Delivers-NVIDIA-Vera-Rubin-NVL72-Performance-at-Production-Scale-Starting-With-Cognition/default.aspx  
  Vendor press release. The first production Vera Rubin cluster and CoreWeave's performance claims. Slide 23.
- **NVIDIA (2025).** *NVIDIA unveils NVLink Fusion (press release, May 2025).* https://investor.nvidia.com/news/press-release-details/2025/NVIDIA-Unveils-NVLink-Fusion-for-Industry-to-Build-Semi-Custom-AI-Infrastructure-With-NVIDIA-Partner-Ecosystem/default.aspx  
  Vendor press release. NVLink opened to partners' CPUs and accelerators; the list of partners. Slide 26.
- **Constellation Research (2025).** *Nvidia's Groq deal: acquisition, acquihire or licensing? (December 2025).* https://www.constellationr.com/insights/news/nvidias-groq-deal-acquisition-acquihire-or-creative-licensing-deal  
  Analyst note, secondary source. The structure of the December 2025 Groq transaction behind the Groq 3 LPX. Slide 26.
- **NVIDIA (2025).** *Introducing NVIDIA Dynamo, a low-latency distributed inference framework (developer blog, March 2025).* https://developer.nvidia.com/blog/introducing-nvidia-dynamo-a-low-latency-distributed-inference-framework-for-scaling-reasoning-ai-models  
  Vendor blog. Disaggregated prefill and decode, KV-cache routing: the software premise of CPX and the LPX. Slides 26 and 29.

## 8. Systems and scale (slides 27-28)

- **TOP500 (2026).** *LineShine debuts at No. 1 as TOP500 enters a new global exascale era (June 2026).* https://www.top500.org/news/lineshine-debuts-no-1-top500-enters-new-global-exascale-era/  
  Benchmark list, open. The June 2026 top ten with accelerators and power. Slide 27.
- **TOP500 (2025).** *El Capitan retains No. 1 as JUPITER becomes Europe's first exascale system (November 2025).* https://top500.org/news/el-capitan-retains-1-as-jupiter-becomes-europes-first-exascale-system-in-the-66th-top500-list/  
  Benchmark list, open. JUPITER's 1.000 EFLOP/s entry. Slide 27.
- **Forschungszentrum Juelich (2025).** *Europe's first supercomputer reaches 1 exaflop/s (press release, November 2025).* https://www.fz-juelich.de/en/news/archive/press-release/2025/europes-first-supercomputer-reaches-1-exaflop-s  
  Laboratory press release. JUPITER: about 24,000 GH200, the Booster configuration. Slide 27.
- **Lawrence Berkeley National Laboratory (2026).** *Berkeley Lab takes major step toward Doudna with delivery of early access system Cech (March 2026).* https://newscenter.lbl.gov/2026/03/17/berkeley-lab-takes-major-step-toward-doudna-with-delivery-of-early-access-system-cech/  
  Laboratory news. Doudna (Dell, Vera Rubin, late 2026) and the Cech system (72 Grace, 144 Blackwell). Slide 27.
- **NERSC (2025).** *Doudna system (NERSC-10).* https://www.nersc.gov/what-we-do/resources/doudna-system  
  Laboratory page. The official description of NERSC's Vera Rubin system.
- **NVIDIA (2025).** *Blue Lion supercomputer at LRZ will run on NVIDIA Vera Rubin (blog).* https://blogs.nvidia.com/blog/blue-lion-vera-rubin/  
  Vendor blog. The LRZ (HPE) Vera Rubin system.
- **NVIDIA (2025).** *NVIDIA, Oracle and the US Department of Energy to build the DOE's largest AI supercomputer (press release, October 28, 2025).* https://nvidianews.nvidia.com/news/nvidia-oracle-us-department-of-energy-ai-supercomputer-scientific-discovery  
  Vendor press release. Solstice (100,000 Blackwell GPUs) and Equinox (10,000) at Argonne. Slide 27.
- **US Department of Energy (2025).** *Energy Department announces new partnership with NVIDIA and Oracle to build largest DOE AI supercomputer.* https://www.energy.gov/articles/energy-department-announces-new-partnership-nvidia-and-oracle-build-largest-doe-ai  
  Government press release. The DOE side of the Solstice and Equinox announcement.
- **Data Center Dynamics (2025).** *OpenAI and Oracle to deploy 450,000 GB200 GPUs at Stargate Abilene.* https://www.datacenterdynamics.com/en/news/openai-and-oracle-to-deploy-450000-gb200-gpus-at-stargate-abilene-data-center/  
  Press, secondary source. The scale and power (1.2 GW) of the largest announced GB200 site. Slides 22 and 27.
- **NVIDIA (2026).** *DGX SuperPOD with DGX Vera Rubin NVL72 (blog).* https://blogs.nvidia.com/blog/dgx-superpod-rubin/  
  Vendor blog. The eight-rack, 576-GPU Vera Rubin pod.
- **NVIDIA (2025).** *NVIDIA Blackwell Ultra sets records in MLPerf Training v5.1 (NVIDIA blog, November 2025).* https://blogs.nvidia.com/blog/mlperf-training-benchmark-blackwell-ultra/  
  Vendor blog. The first NVFP4 training submission in MLPerf (Llama 3.1 405B on GB300), the chronology behind slide 12's adoption line. Slides 12 and 20.
- **NVIDIA (2026).** *NVIDIA Blackwell tops MLPerf Training 6.0 (developer blog, June 2026).* https://developer.nvidia.com/blog/nvidia-blackwell-tops-mlperf-training-6-0-with-industry-leading-scale-and-performance/  
  Vendor blog. The 8,192-GPU GB300 results (DeepSeek-V3 671B in 2.02 minutes) and the GB300-to-GB200 ratios. Slide 20.
- **MLCommons (2026).** *MLPerf Training v6.0 supplemental results discussion (June 2026).* https://mlcommons.org/wp-content/uploads/2026/06/Final-MLPerf-Training-v6.0-Supplemental-Discussion-UNDER-EMBARGO-UNTIL-6_16_26-8_00-AM-PT.pdf  
  Benchmark consortium document. The official analysis of the round.
- **MLCommons (2026).** *MLCommons releases new MLPerf Inference v6.0 benchmark results (April 2026).* https://www.streetinsider.com/Press+Releases/MLCommons+Releases+New+MLPerf+Inference+v6.0+Benchmark+Results/26256741.html  
  Press release (mirror). The round's new benchmarks and largest systems.
- **TrendForce (2026).** *Rubin faces delays; Blackwell to exceed 70 percent of NVIDIA's 2026 high-end shipments (April 2026).* https://www.trendforce.com/presscenter/news/20260408-13003.html  
  Analyst press release, secondary source. The 2026 product mix and the reasons given for Rubin's slower ramp.

## 9. Software (slide 29)

- **NVIDIA (2025).** *CUDA Toolkit 13.0 release notes.* https://docs.nvidia.com/cuda/archive/13.0.0/cuda-toolkit-release-notes/index.html  
  Vendor documentation. Architecture deprecations (Maxwell, Pascal, Volta) and the driver requirement. Slide 29.
- **NVIDIA (2022).** *CUDA Toolkit 12.0 release notes.* https://docs.nvidia.com/cuda/archive/12.0.0/cuda-toolkit-release-notes/index.html  
  Vendor documentation. Hopper and Ada enablement, clusters and the new PTX. Slide 29.
- **NVIDIA (2022).** *Transformer Engine (GitHub repository and documentation).* https://github.com/NVIDIA/TransformerEngine  
  Vendor software, open source. The FP8 (and later MXFP8 and NVFP4) training library: recipes, delayed scaling, layer wrappers. Slides 12 and 29.
- **Thakkar et al. (NVIDIA) (2023).** *CUTLASS 3 and CuTe (GitHub repository and documentation).* https://github.com/NVIDIA/cutlass  
  Vendor software, open source. The template library that exposes TMA, wgmma, clusters and tcgen05 to kernel writers. Slides 13 and 29.
- **Patel, Nishball and Knuhtsen (SemiAnalysis) (2024).** *MI300X vs H100 vs H200 benchmark part 1: training (December 2024).* https://newsletter.semianalysis.com/p/mi300x-vs-h100-vs-h200-benchmark-part-1-training  
  Analyst report, secondary source. Achieved GEMM throughput against peak (about 720 of 989 TFLOP/s on the H100) and the software argument. Slide 29.
- **NVIDIA (2025).** *CUDA Python and cuTile (GTC 2025 announcements, developer blog).* https://developer.nvidia.com/blog/cuda-python-and-cutile/  
  Vendor blog. The tile-based programming model and Python-native CUDA announced at GTC 2025. Slide 29.

## 10. Wrap-up, retrospectives and the spec-sheet record (slides 30-32)

- **NVIDIA (2022).** *NVIDIA H100 Tensor Core GPU architecture (official download page).* https://resources.nvidia.com/en-us-tensor-core/gtc22-whitepaper-hopper  
  Vendor whitepaper (registration). The official copy of the Hopper whitepaper for citation.
- **NVIDIA (2023).** *H100 datasheet (official download page).* https://resources.nvidia.com/en-us-grace-cpu/h100-datasheet-24306-1  
  Vendor datasheet (registration). The official copy of the shipping H100 specifications.
- **Wikipedia (2026).** *Rubin (microarchitecture).* https://en.wikipedia.org/wiki/Rubin_(microarchitecture)  
  Tertiary source. A pointer page with dated citations; useful for finding primary sources, not for quoting.
- **NVIDIA (2026).** *CES 2026 keynote (video).* https://www.youtube.com/live/0NBILspM4c4  
  Primary presentation. The Rubin slides as shown, including the transistor count that appears in no press release.
- **HPCwire / AIwire (2026).** *Huang shares NVIDIA roadmap: NVL1152, scale-up CPO (March 2026).* https://www.hpcwire.com/aiwire/2026/03/18/huang-shares-nvidia-roadmap-showing-more-chips-nvl1152-scale-up-cpo/  
  Press, secondary source. The GTC 2026 roadmap through Feynman. Slide 26.
- **SemiHub (2026).** *Hot Chips 2026 recap: key presentations.* https://semihub.io/en/blog/hot-chips-2026-recap.html  
  Press, secondary source. Rubin and Vera beside AMD's MI400 in the same session; the comparison the next lecture takes up.
